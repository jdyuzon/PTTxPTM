#!/bin/bash
#
#  submit by  sbatch HardFilder.sh
#
#  specify the job name
#SBATCH --job-name=GATK
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 30min
#SBATCH --time=30:00:00
#  maximum requested memory
#SBATCH --mem=15G
#  write std out and std error to these files
#SBATCH --error=gatk.%J.err
#SBATCH --output=gatk.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#  add your code here:  

cd /home/taliadoros/bwa/stampy/sorted/merged/merged/RGed/index/haplotype_caller/
reference=/home/taliadoros/Reff_gen/0-1_assembly.v14.fa

gatk SelectVariants \
     -R $reference \
     -V ExcludeFilters.vcf \
     --select-type-to-include SNP \
     -O snpHardF.vcf

gatk SelectVariants \
     -R $reference \
     -V FilteredRM.recode.vcf \
     --select-type-to-include SNP \
     -O snpindiv.vcf

gatk SelectVariants \
     -R $reference \
     -V FullyFiltered.recode.vcf \
     --select-type-to-include SNP \
     -O snppos.vcf

gatk SelectVariants \
     -R $reference \
     -V VariantOnly.vcf \
     --select-type-to-include SNP \
     -O VarSNPs.vcf


