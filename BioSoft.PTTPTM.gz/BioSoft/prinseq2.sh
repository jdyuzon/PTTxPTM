#!/bin/bash
#
#  submit by  sbatch prinseq.sh
#
#  specify the job name
#SBATCH --job-name=prinseq
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=10:00:00
#  maximum requested memory
#SBATCH --mem=10G
#  write std out and std error to these files
#SBATCH --error=prinseq.%J.err
#SBATCH --output=prinseq.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#  add your code here:
trimmed=/mnt/beegfs/yuzon/trimmed/
unassembled=unassembled/
assembled=assembled/
fastqc_outdir1=prinseq/fastqc
fastqc_outdir2=assembled/fastqc

module load perl/5.26.1

#mkdir ${pear}${fastqc_outdir1}
#mkdir ${pear}${fastqc_outdir2}
cd ${trimmed}

for each in *1.fastq
do
echo ${each}
perl /data/biosoftware/prinseq/bin/prinseq-lite.pl -fastq ${each} -fastq2 ${each%1.fastq}2.fastq -log -verbose -derep 14 -out_format 3 -out_good ${trimmed}${each%1.fastq}

fastqc ${each%1.fastq}_* --outdir ${trimmed}${fastqc_outdir1}

done

#cd ${pear}${assembled}

#for each in F*assembled.fastq
#do
#echo ${each}
#perl /data/biosoftware/prinseq/bin/prinseq-lite.pl -fastq ${each} -log -verbose -derep 14 -trim_qual_left 30 -trim_qual_right 30 -trim_qual_window 30 -trim_qual_step 3 -min_len 40 -out_format 3 -out_good ${pear}${assembled}${each%assembled.fastq}1

#fastqc ${each%assembled.fastq}1* --outdir ${pear}${fastqc_outdir2}

#done
