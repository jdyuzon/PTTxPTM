#!/bin/bash
#
#  submit by  sbatch Haplotype_caller.sh
#
#  specify the job name
#SBATCH --job-name=PTTxPTMhybrid
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=90:00:00
#  maximum requested memory
#SBATCH --mem=15G
#  write std out and std error to these files
#SBATCH --error=PTTxPTMhybrid.%J.err
#SBATCH --output=PTTxPTMhybrid.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

###########################################################
echo "Input Isolate Name" $entry###########################
###########################################################

entry=$1

###########################################################
echo "Software"
###########################################################
##module load java/x64/8u121

trimmo=/data/biosoftware/Trimmomatic/Trimmomatic-0.38/
pear=/data/biosoftware/pear/pear-0.9.10-bin-64/pear-0.9.10-bin-64 
export BBMAPDIR=/data/biosoftware/bbmap/bbmap
bwa_soft=/data/biosoftware/bwa/bwa-0.7.15/
stampy_soft=/data/biosoftware/stampy/stampy/
samtools_soft=/data/biosoftware/samtools/samtools-1.9/
fastqc=/data/biosoftware/FastQC/FastQC/fastqc


##########################################################
echo "Directories"
##########################################################

refPTT=/home/yuzon/references/hybrid_references/PTT_0-1_assembly.v14.fa
refPTM=/home/yuzon/references/hybrid_references/PTM_FGOB10Ptm-1_assembly.v7.fasta
merged_genome=/home/yuzon/references/hybrid_references/merged_genome_PTTxPTM.fasta
####index fasta
#bwa index /home/yuzon/references/hybrid_references/merged_genome_PTTxPTM.fasta

Raw_reads=/home/yuzon/raw_reads/
Raw_fastqc=/home/yuzon/PTTxPTMtest/fastQC/raw_fastqc
trimmed=/home/yuzon/PTTxPTMtest/trimmed/

PEoverlap=/home/yuzon/PTTxPTMtest/trimmed/pear/
Pear_fastqc=/home/yuzon/PTTxPTMtest/fastQC/fastqc_pear
assembled=/home/yuzon/PTTxPTMtest/trimmed/pear/assembled/
unassembled=/home/yuzon/PTTxPTMtest/trimmed/pear/unassembled/
unassembled_fastqc=/home/yuzon/PTTxPTMtest/fastQC/fastqc_unassembled
assembled_fastqc=/home/yuzon/PTTxPTMtest/fastQC/fastqc_assembled

markdup=/home/yuzon/PTTxPTMtest/trimmed/prinseq/
markdup_fastQC=/home/yuzon/PTTxPTMtest/fastQC/markdup

bin_genome=/home/yuzon/PTTxPTMtest/bbsplit/
bwa_out=/home/yuzon/PTTxPTMtest/aligned/

stampy_realign=/home/yuzon/PTTxPTMtest/aligned/stampy/
flag_out=/home/yuzon/PTTxPTMtest/aligned/stampy/flag/
readgroup_files=/home/yuzon/PTTxPTMtest/aligned/sorted/readgroups/

Sorted=/home/yuzon/PTTxPTMtest/aligned/sorted/
Depth_dir=/home/yuzon/PTTxPTMtest/aligned/sorted/stats/depth/
dups_dir=/home/yuzon/PTTxPTMtest/aligned/sorted/stats/dups/

snps=/home/yuzon/PTTxPTMtest/SNPcalling/

gridss=/home/yuzon/PTTxPTMtest/gridss
manta=/home/yuzon/PTTxPTMtest/manta
parsnp_qry=/home/yuzon/PTTxPTMtest/SNPcalling/parsnp_qry/
parsnp_out=/home/yuzon/PTTxPTMtest/SNPcalling/parsnp_out/

#mkdir $refPTT
#mkdir $refPTM
#mkdir $merged_genome

#mkdir $Raw_reads
#mkdir $Raw_fastqc
#mkdir $trimmed

#mkdir $PEoverlap
#mkdir $Pear_fastqc
#mkdir $assembled
#mkdir $unassembled
#mkdir $unassembled_fastqc
#mkdir $assembled_fastqc

#mkdir $markdup
#mkdir $markdup

#mkdir $bin_genome

#mkdir $readgroup_files

#mkdir $bwa_out

#mkdir $stampy_realign
#mkdir $flag_out

#mkdir $Sorted
#mkdir $Depth_dir

#mkdir $snps

mkdir $gridss
mkdir $manta
mkdir $parsnp_qry
mkdir $parsnp_out


#########################################################################################################
echo "GRIDSS: Interchromosomal Translocations/recomb sites & other SVs"##################################
#########################################################################################################
module load R/3.5.3
module load java/x64/8u121

#export LC_ALL=C
#/data/biosoftware/gridss/gridss/gridss.sh --reference ${merged_genome} --output PTTxPTMhybrid.gridss.vcf.gz --assembly gridss.assembly.bam \
#--threads 4 --jar /data/biosoftware/gridss/gridss/gridss.jar --workingdir ${gridss} --jvmheap 25g --steps All --maxcoverage 50000 --picardoptions VALIDATION_STRINGENCY=LENIENT \
#--labels 100,101,102,103,104,105,106,107,108,109,10,110,111,112,113,114,115,116,117,118,119,11,120,12,13,14,15,16,17,18,19,1,20,21,22,23,24,25,26,27,28,29,2,30,31,32,33,34,35,36,37,38,39,3,40,41,42,43,44,45,46,47,48,49,4,50,51,52,53,54,55,56,57,58,59,5,60,61,62,63,64,65,66,67,68,69,6,70,72,73,74,75,76,77,78,79b,79,7,80,81,82,83,84,85,86,87,88,89,8,90,91,92,93,94,95,96,97,98,99,9 100.PTMPTT.read.bam 101.PTMPTT.read.bam 102.PTMPTT.read.bam 103.PTMPTT.read.bam 104.PTMPTT.read.bam 105.PTMPTT.read.bam 106.PTMPTT.read.bam 107.PTMPTT.read.bam 108.PTMPTT.read.bam 109.PTMPTT.read.bam 10.PTMPTT.read.bam 110.PTMPTT.read.bam 111.PTMPTT.read.bam 112.PTMPTT.read.bam 113.PTMPTT.read.bam 114.PTMPTT.read.bam 115.PTMPTT.read.bam 116.PTMPTT.read.bam 117.PTMPTT.read.bam 118.PTMPTT.read.bam 119.PTMPTT.read.bam 11.PTMPTT.read.bam 120.PTMPTT.read.bam 12.PTMPTT.read.bam 13.PTMPTT.read.bam 14.PTMPTT.read.bam 15.PTMPTT.read.bam 16.PTMPTT.read.bam 17.PTMPTT.read.bam 18.PTMPTT.read.bam 19.PTMPTT.read.bam 1.PTMPTT.read.bam 20.PTMPTT.read.bam 21.PTMPTT.read.bam 22.PTMPTT.read.bam 23.PTMPTT.read.bam 24.PTMPTT.read.bam 25.PTMPTT.read.bam 26.PTMPTT.read.bam 27.PTMPTT.read.bam 28.PTMPTT.read.bam 29.PTMPTT.read.bam 2.PTMPTT.read.bam 30.PTMPTT.read.bam 31.PTMPTT.read.bam 32.PTMPTT.read.bam 33.PTMPTT.read.bam 34.PTMPTT.read.bam 35.PTMPTT.read.bam 36.PTMPTT.read.bam 37.PTMPTT.read.bam 38.PTMPTT.read.bam 39.PTMPTT.read.bam 3.PTMPTT.read.bam 40.PTMPTT.read.bam 41.PTMPTT.read.bam 42.PTMPTT.read.bam 43.PTMPTT.read.bam 44.PTMPTT.read.bam 45.PTMPTT.read.bam 46.PTMPTT.read.bam 47.PTMPTT.read.bam 48.PTMPTT.read.bam 49.PTMPTT.read.bam 4.PTMPTT.read.bam 50.PTMPTT.read.bam 51.PTMPTT.read.bam 52.PTMPTT.read.bam 53.PTMPTT.read.bam 54.PTMPTT.read.bam 55.PTMPTT.read.bam 56.PTMPTT.read.bam 57.PTMPTT.read.bam 58.PTMPTT.read.bam 59.PTMPTT.read.bam 5.PTMPTT.read.bam 60.PTMPTT.read.bam 61.PTMPTT.read.bam 62.PTMPTT.read.bam 63.PTMPTT.read.bam 64.PTMPTT.read.bam 65.PTMPTT.read.bam 66.PTMPTT.read.bam 67.PTMPTT.read.bam 68.PTMPTT.read.bam 69.PTMPTT.read.bam 6.PTMPTT.read.bam 70.PTMPTT.read.bam 72.PTMPTT.read.bam 73.PTMPTT.read.bam 74.PTMPTT.read.bam 75.PTMPTT.read.bam 76.PTMPTT.read.bam 77.PTMPTT.read.bam 78.PTMPTT.read.bam 79b.PTMPTT.read.bam 79.PTMPTT.read.bam 7.PTMPTT.read.bam 80.PTMPTT.read.bam 81.PTMPTT.read.bam 82.PTMPTT.read.bam 83.PTMPTT.read.bam 84.PTMPTT.read.bam 85.PTMPTT.read.bam 86.PTMPTT.read.bam 87.PTMPTT.read.bam 88.PTMPTT.read.bam 89.PTMPTT.read.bam 8.PTMPTT.read.bam 90.PTMPTT.read.bam 91.PTMPTT.read.bam 92.PTMPTT.read.bam 93.PTMPTT.read.bam 94.PTMPTT.read.bam 95.PTMPTT.read.bam 96.PTMPTT.read.bam 97.PTMPTT.read.bam 98.PTMPTT.read.bam 99.PTMPTT.read.bam 9.PTMPTT.read.bam

##########################################################
echo "GATK: CombineGVCFs"#################################
##########################################################
cd $snps
##sed 's/--bam/--variant/g'  aligned/sorted/mantaList|sed 's/read.bam/vcf.gz/g' >vcfList
#gatk CombineGVCFs \
#   -R ${merged_genome} -LE true \
#--variant 100.PTMPTT.vcf.gz \
#--variant 101.PTMPTT.vcf.gz \
#--variant 102.PTMPTT.vcf.gz \
#--variant 103.PTMPTT.vcf.gz \
#--variant 104.PTMPTT.vcf.gz \
#--variant 105.PTMPTT.vcf.gz \
#--variant 106.PTMPTT.vcf.gz \
#--variant 107.PTMPTT.vcf.gz \
#--variant 108.PTMPTT.vcf.gz \
#--variant 109.PTMPTT.vcf.gz \
#--variant 10.PTMPTT.vcf.gz \
#--variant 110.PTMPTT.vcf.gz \
#--variant 111.PTMPTT.vcf.gz \
#--variant 112.PTMPTT.vcf.gz \
#--variant 113.PTMPTT.vcf.gz \
#--variant 114.PTMPTT.vcf.gz \
#--variant 115.PTMPTT.vcf.gz \
#--variant 116.PTMPTT.vcf.gz \
#--variant 117.PTMPTT.vcf.gz \
#--variant 118.PTMPTT.vcf.gz \
#--variant 119.PTMPTT.vcf.gz \
#--variant 11.PTMPTT.vcf.gz \
#--variant 120.PTMPTT.vcf.gz \
#--variant 12.PTMPTT.vcf.gz \
#--variant 13.PTMPTT.vcf.gz \
#--variant 14.PTMPTT.vcf.gz \
#--variant 15.PTMPTT.vcf.gz \
#--variant 16.PTMPTT.vcf.gz \
#--variant 17.PTMPTT.vcf.gz \
#--variant 18.PTMPTT.vcf.gz \
#--variant 19.PTMPTT.vcf.gz \
#--variant 1.PTMPTT.vcf.gz \
#--variant 20.PTMPTT.vcf.gz \
#--variant 21.PTMPTT.vcf.gz \
#--variant 22.PTMPTT.vcf.gz \
#--variant 23.PTMPTT.vcf.gz \
#--variant 24.PTMPTT.vcf.gz \
#--variant 25.PTMPTT.vcf.gz \
#--variant 26.PTMPTT.vcf.gz \
#--variant 27.PTMPTT.vcf.gz \
#--variant 28.PTMPTT.vcf.gz \
#--variant 29.PTMPTT.vcf.gz \
#--variant 2.PTMPTT.vcf.gz \
#--variant 30.PTMPTT.vcf.gz \
#--variant 31.PTMPTT.vcf.gz \
#--variant 32.PTMPTT.vcf.gz \
#--variant 33.PTMPTT.vcf.gz \
#--variant 34.PTMPTT.vcf.gz \
#--variant 35.PTMPTT.vcf.gz \
#--variant 36.PTMPTT.vcf.gz \
#--variant 37.PTMPTT.vcf.gz \
#--variant 38.PTMPTT.vcf.gz \
#--variant 39.PTMPTT.vcf.gz \
#--variant 3.PTMPTT.vcf.gz \
#--variant 40.PTMPTT.vcf.gz \
#--variant 41.PTMPTT.vcf.gz \
#--variant 42.PTMPTT.vcf.gz \
#--variant 43.PTMPTT.vcf.gz \
#--variant 44.PTMPTT.vcf.gz \
#--variant 45.PTMPTT.vcf.gz \
#--variant 46.PTMPTT.vcf.gz \
#--variant 47.PTMPTT.vcf.gz \
#--variant 48.PTMPTT.vcf.gz \
#--variant 49.PTMPTT.vcf.gz \
#--variant 4.PTMPTT.vcf.gz \
#--variant 50.PTMPTT.vcf.gz \
#--variant 51.PTMPTT.vcf.gz \
#--variant 52.PTMPTT.vcf.gz \
#--variant 53.PTMPTT.vcf.gz \
#--variant 54.PTMPTT.vcf.gz \
#--variant 55.PTMPTT.vcf.gz \
#--variant 56.PTMPTT.vcf.gz \
#--variant 57.PTMPTT.vcf.gz \
#--variant 58.PTMPTT.vcf.gz \
#--variant 59.PTMPTT.vcf.gz \
#--variant 5.PTMPTT.vcf.gz \
#--variant 60.PTMPTT.vcf.gz \
#--variant 61.PTMPTT.vcf.gz \
#--variant 62.PTMPTT.vcf.gz \
#--variant 63.PTMPTT.vcf.gz \
#--variant 64.PTMPTT.vcf.gz \
#--variant 65.PTMPTT.vcf.gz \
#--variant 66.PTMPTT.vcf.gz \
#--variant 67.PTMPTT.vcf.gz \
#--variant 68.PTMPTT.vcf.gz \
#--variant 69.PTMPTT.vcf.gz \
#--variant 6.PTMPTT.vcf.gz \
#--variant 70.PTMPTT.vcf.gz \
#--variant 72.PTMPTT.vcf.gz \
#--variant 73.PTMPTT.vcf.gz \
#--variant 74.PTMPTT.vcf.gz \
#--variant 75.PTMPTT.vcf.gz \
#--variant 76.PTMPTT.vcf.gz \
#--variant 77.PTMPTT.vcf.gz \
#--variant 78.PTMPTT.vcf.gz \
#--variant 79b.PTMPTT.vcf.gz \
#--variant 79.PTMPTT.vcf.gz \
#--variant 7.PTMPTT.vcf.gz \
#--variant 80.PTMPTT.vcf.gz \
#--variant 81.PTMPTT.vcf.gz \
#--variant 82.PTMPTT.vcf.gz \
#--variant 83.PTMPTT.vcf.gz \
#--variant 84.PTMPTT.vcf.gz \
#--variant 85.PTMPTT.vcf.gz \
#--variant 86.PTMPTT.vcf.gz \
#--variant 87.PTMPTT.vcf.gz \
#--variant 88.PTMPTT.vcf.gz \
#--variant 89.PTMPTT.vcf.gz \
#--variant 8.PTMPTT.vcf.gz \
#--variant 90.PTMPTT.vcf.gz \
#--variant 91.PTMPTT.vcf.gz \
#--variant 92.PTMPTT.vcf.gz \
#--variant 93.PTMPTT.vcf.gz \
#--variant 94.PTMPTT.vcf.gz \
#--variant 95.PTMPTT.vcf.gz \
#--variant 96.PTMPTT.vcf.gz \
#--variant 97.PTMPTT.vcf.gz \
#--variant 98.PTMPTT.vcf.gz \
#--variant 99.PTMPTT.vcf.gz \
#--variant 9.PTMPTT.vcf.gz \
#-O hybrids.g.vcf.gz

##########################################################
echo "GATK: Call Genotypes"###############################
##########################################################

java -jar /data/biosoftware/GATK/GATK/GenomeAnalysisTK.jar \
-T GenotypeGVCFs \
-R $merged_genome \
--variant hybrids.g.vcf.gz \
-o hybrids.geno.vcf.gz



##########################################################
echo "BCFtools: set low AD to missing "###################
##########################################################

bcftools filter -e 'FORMAT/AD[*:0] < 2 | FORMAT/AD[*:1] < 2 | FORMAT/AD[*:2] < 2'  --set-GTs .  hybrids.geno.vcf.gz > hybrids.flt.vcf


##########################################################
echo "Bedtools Makefasta: VCF to FASTA "##################
##########################################################

for sample in `bcftools query -l hybrids.flt.vcf`
do
echo $sample
vcf-subset -c $sample hybrids.flt.vcf > ${sample}.vcf
bedtools maskfasta -fi $merged_genome -bed ${sample}.vcf -fo ${sample}.fasta
done

############################################################
#### Split isolate.fasta files to PTT and PTM ##############
############################################################
awk '{print $0 "\t" $1}' /home/yuzon/references/hybrid_references/PTTxPTM_tracks.bed \
|grep 'PTM\|mito' > /home/yuzon/references/hybrid_references/PTM_tracks.bed
awk '{print $0 "\t" $1}' /home/yuzon/references/hybrid_references/PTTxPTM_tracks.bed \
|grep 'PTT\|0-1' > /home/yuzon/references/hybrid_references/PTT_tracks.bed

for each in *.PTMPTT.fasta
do
bedtools getfasta -name -fi ${each} -bed /home/yuzon/references/hybrid_references/PTM_tracks.bed -fo ${parsnp_qry}${each%.PTMPTT.fasta}.PTM.fasta
bedtools getfasta -name -fi ${each} -bed /home/yuzon/references/hybrid_references/PTT_tracks.bed -fo ${parsnp_qry}${each%.PTMPTT.fasta}.PTT.fasta
done

############################################################
#### parSNP: Merge FASTAs for recombination blocks #########
############################################################

/data/biosoftware/harvest/harvest/parsnp -r $refPTT -d  $parsnp_qry -o $parsnp_out


##########################################################
echo "GATK: Remove loci based on missing info"############
##########################################################
gatk SelectVariants \
	-V hybrids.flt.vcf \
	--set-filtered-gt-to-nocall \
	-O hybrids.fltnocall.vcf





