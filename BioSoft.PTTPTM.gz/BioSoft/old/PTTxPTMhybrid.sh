#!/bin/bash
#
#  submit by  sbatch Haplotype_caller.sh
#
#  specify the job name
#SBATCH --job-name=PTTxPTMhybrid
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=90:00:00
#  maximum requested memory
#SBATCH --mem=15G
#  write std out and std error to these files
#SBATCH --error=PTTxPTMhybrid.%J.err
#SBATCH --output=PTTxPTMhybrid.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

###########################################################
echo "Software"
###########################################################
##module load java/x64/8u121

trimmo=/data/biosoftware/Trimmomatic/Trimmomatic-0.38/
pear=/data/biosoftware/pear/pear-0.9.10-bin-64/pear-0.9.10-bin-64 
export BBMAPDIR=/data/biosoftware/bbmap/bbmap
bwa_soft=/data/biosoftware/bwa/bwa-0.7.15/
stampy_soft=/data/biosoftware/stampy/stampy/
samtools_soft=/data/biosoftware/samtools/samtools-1.9/
fastqc=/data/biosoftware/FastQC/FastQC/fastqc


##########################################################
echo "Directories"
##########################################################

refPTT=/home/yuzon/references/hybrid_references/PTT_0-1_assembly.v14.fa
refPTM=/home/yuzon/references/hybrid_references/PTM_FGOB10Ptm-1_assembly.v7.fasta
merged_genome=/home/yuzon/references/hybrid_references/merged_genome_PTTxPTM.fasta
####index fasta
#bwa index /home/yuzon/references/hybrid_references/merged_genome_PTTxPTM.fasta

Raw_reads=/home/yuzon/raw_reads/
Raw_fastqc=/home/yuzon/PTTxPTMtest/fastQC/raw_fastqc
trimmed=/home/yuzon/PTTxPTMtest/trimmed/

PEoverlap=/home/yuzon/PTTxPTMtest/trimmed/pear/
Pear_fastqc=/home/yuzon/PTTxPTMtest/fastQC/fastqc_pear
assembled=/home/yuzon/PTTxPTMtest/trimmed/pear/assembled/
unassembled=/home/yuzon/PTTxPTMtest/trimmed/pear/unassembled/
unassembled_fastqc=/home/yuzon/PTTxPTMtest/fastQC/fastqc_unassembled
assembled_fastqc=/home/yuzon/PTTxPTMtest/fastQC/fastqc_assembled

markdup=/home/yuzon/PTTxPTMtest/trimmed/prinseq/
markdup_fastQC=/home/yuzon/PTTxPTMtest/fastQC/markdup

bin_genome=/home/yuzon/PTTxPTMtest/bbsplit/
bwa_out=/home/yuzon/PTTxPTMtest/aligned/

stampy_realign=/home/yuzon/PTTxPTMtest/aligned/stampy/
flag_out=/home/yuzon/PTTxPTMtest/aligned/stampy/flag/
readgroup_files=/home/yuzon/PTTxPTMtest/aligned/sorted/readgroups/

Sorted=/home/yuzon/PTTxPTMtest/aligned/sorted/
Depth_dir=/home/yuzon/PTTxPTMtest/aligned/sorted/stats/depth/
dups_dir=/home/yuzon/PTTxPTMtest/aligned/sorted/stats/dups/

snps=/home/yuzon/PTTxPTMtest/SNPcalling/

gridss=/home/yuzon/PTTxPTMtest/gridss
manta=/home/yuzon/PTTxPTMtest/manta

#mkdir $refPTT
#mkdir $refPTM
#mkdir $merged_genome

#mkdir $Raw_reads
#mkdir $Raw_fastqc
#mkdir $trimmed

#mkdir $PEoverlap
#mkdir $Pear_fastqc
#mkdir $assembled
#mkdir $unassembled
#mkdir $unassembled_fastqc
#mkdir $assembled_fastqc

#mkdir $markdup
#mkdir $markdup

#mkdir $bin_genome

#mkdir $readgroup_files

#mkdir $bwa_out

#mkdir $stampy_realign
#mkdir $flag_out

#mkdir $Sorted
#mkdir $Depth_dir

#mkdir $snps

mkdir $gridss
mkdir $manta

#####################################################
echo "Trim adaptors, min quality =30, min length =40"
#####################################################
cd ${Raw_reads}
#for each in *1.fq.gz
#do
#echo ${each}
#java -jar ${trimmo}trimmomatic-0.38.jar PE -threads 5 \
 #     $each ${each%1.fq.gz}2.fq.gz \
  #    ${trimmed}${each%1.fq.gz}P_1.fastq ${trimmed}${each%1.fq.gz}U_1.fastq \
   #   ${trimmed}${each%1.fq.gz}P_2.fastq ${trimmed}${each%1.fq.gz}U_2.fastq \
    #  ILLUMINACLIP:${trimmo}adapters/TruSeq3-PE-2.fa:2:30:10 \
     # SLIDINGWINDOW:3:28 MINLEN:40
#done

#FastQC

#cd ${trimmed}
#for each in *fastq
#do
#${fastqc} ${each}
#done


####################################################
echo "PEAR: merge overlapping paired reads"#########
####################################################
cd ${trimmed}
###DONT USE REMOVES TOO MUCH DATA
##for each in *P_1.fastq
##do
##${pear} -f  ${each} -j 4 -r ${each%_1.fastq}_2.fastq -n 0 -k -o ${each%_1.fastq}

##${fastqc} ${each%_1.fastq}.assembled.fastq \
##${each%_1.fastq}.unassembled.forward.fastq ${each%_1.fastq}.unassembled.reverse.fastq \
##--outdir ${Pear_fastqc}
##done

##mv *unassembled.fastq ${unassembled}
##mv *assembled.fastq ${assembled}


##########################################################################################################
echo "Merge Singleton Files: Trimmomatic Unpaired (For and Rev) and PEAR (Paired overlap/assembled)"######
##########################################################################################################
#for each in *_U_1.fastq
#do
#cat ${each} \
#${each%_U_1.fastq}_U_2.fastq \
#> ${assembled}${each%_U_1.fastq}.singles.fastq

#done



###########################################################
echo "Prinseq: remove PCR duplicates"######################
###########################################################
###prinseq needs this version of perl but this version interferes with other software

module load perl/5.26.1

cd ${assembled}
##singles
#for each in *singles.fastq
#do
#echo ${each}
#perl /data/biosoftware/prinseq/bin/prinseq-lite.pl -fastq ${each} \
#-log -verbose -derep 14 -trim_qual_left 30 -trim_qual_right 30 -trim_qual_window 30 -trim_qual_step 3 \
#-min_len 40 -out_format 3 -out_good ${markdup}${each%.singles.fastq}.markdup
#done

##paired
cd ${trimmed}

#for each in *_P_1.fastq 
#do 
#echo ${each}
#echo ${each%_P_1}_P_2.fastq 
#perl /data/biosoftware/prinseq/bin/prinseq-lite.pl \
#-fastq ${each} \
#-fastq2 ${each%_P_1.fastq}_P_2.fastq \
#-log -verbose -derep 14 -out_format 3 \
#-out_good ${markdup}${each%_P_1.fastq}.markdup

#done

###prinseq needs this version of perl but this version interferes with other software
module unload perl/5.26.1 

#for each in *_P_1.fastq
#do
#fastqc ${markdup}${each%_P_1.fastq}.markdup_1.fastq --outdir ${markdup_fastqc}
#fastqc ${markdup}${each%_P_1.fastq}.markdup_2.fastq --outdir ${markdup_fastqc}
#fastqc ${markdup}${each%_P_1.fastq}.markdup.fastq --outdir ${markdup_fastqc}
#done


#################################################################
echo "BBSplit: Bin reads to best matching Parent Genome"#########
#################################################################
cd ${markdup}

#for each in *.markdup_1.fastq
#do
#####paired (ambiguous2=all map to both genomes)
#$BBMAPDIR/bbsplit.sh minratio=0.52 ambiguous=best ambiguous2=all \
#in1=${each} in2=${each%.markdup_1.fastq}.markdup_2.fastq \
#ref=$refPTT,$refPTM basename=${bin_genome}${each%.markdup_1.fastq}_P_%.fq
#####singles
#$BBMAPDIR/bbsplit.sh minratio=0.52 ambiguous=best ambiguous2=all \
#in1=${each%.markdup_1.fastq}.markdup.fastq \
#ref=$refPTT,$refPTM basename=${bin_genome}${each%.markdup_1.fastq}_%.fq
#done


#########################################################
echo "Trimmomatic: Trim reads based on quality"##########
#########################################################
##cd ${bin_genome}
#######don't use before bbsplit because different read numbers in paired file
#######filter similar to first trimmomatic stepu
##for each in *_1..fastq
##do
##echo ${each}
##java -jar /data/biosoftware/Trimmomatic/Trimmomatic-0.38/trimmomatic-0.38.jar \
##PE ${each} ${each%_1.markdup.fastq}_2.markdup.fastq \
##${each%_1.markdup.fastq}.qual.fastq \
##LEADING:30 SLIDINGWINDOW:3:30 MINLEN:40
##${fastqc} ${each%.markdup.fastq}.qual.fastq
##done

##for each in *markdup.fastq
##do
##echo ${each}
##java -jar /data/biosoftware/Trimmomatic/Trimmomatic-0.38/trimmomatic-0.38.jar \
##SE ${each} ${each%.markdup.fastq}.qual.fastq LEADING:30 SLIDINGWINDOW:3:30 MINLEN:40
##${fastqc} ${each%.markdup.fastq}.qual.fastq
##done


##########################################################
echo "BWA: Alignment"#####################################
##########################################################
cd ${bin_genome}

#${bwa_soft}bwa index ${refPTT}
#${bwa_soft}bwa index ${refPTM}

#####map to PTT
#for each in *_P_PTT_0-1_assembly.v14.fq
#do
#isolate=${each%_P_PTT_0-1_assembly.v14.fq}
#echo $isolate
#${bwa_soft}bwa mem -M -t 4 -p ${refPTT} ${each} \
#> ${bwa_out}${each%_P_PTT_0-1_assembly.v14.fq}.PTT.PE.sam

#${bwa_soft}bwa mem -M -t 4 ${refPTT} \
#${isolate}_PTT_0-1_assembly.v14.fq > ${bwa_out}${isolate}.PTT.SE.sam
#done


#####map to PTM
#for each in *_P_PTM_FGOB10Ptm-1_assembly.v7.fq
#do
#isolate=${each%_P_PTM_FGOB10Ptm-1_assembly.v7.fq}
#echo $isolate
#${bwa_soft}bwa mem -M -t 4 -p ${refPTM} ${each} \
#> ${bwa_out}${each%_P_PTM_FGOB10Ptm-1_assembly.v7.fq}.PTM.PE.sam

#${bwa_soft}bwa mem -M -t 4 ${refPTM} \
#${isolate}_PTM_FGOB10Ptm-1_assembly.v7.fq > ${bwa_out}${isolate}.PTM.SE.sam

###concatenate PTT and PTM bam files
###cat ${bwa_out}${isolate}.PTM.PE.sam  ${bwa_out}${isolate}.PTT.PE.sam >${bwa_out}${isolate}.PTMPTT.PE.sam
###cat ${bwa_out}${isolate}.PTM.SE.sam  ${bwa_out}${isolate}.PTT.SE.sam >${bwa_out}${isolate}.PTMPTT.SE.sam
#done



##########################################################
echo "Stampy: Indel Realigner/Assess Insert Size"#########
##########################################################
module load python/2.7.13

cd ${bwa_out}
####make BAM
#for each in *SE.sam
#do
#echo ${each}
#${samtools_soft}samtools view -S -b ${each} > ${each%.sam}.bam  
#${samtools_soft}samtools view -S -b ${each%.SE.sam}.PE.sam > ${each%.SE.sam}.PE.bam
#done

####stampy
#rm ptg*
#${stampy_soft}stampy.py -G ptg ${refPTT}
#${stampy_soft}stampy.py -g ptg -H ptg

#for each in *PTT.SE.bam
#do
#echo ${each}
#${stampy_soft}stampy.py -g ptg -h ptg -t4 --bamkeepgoodreads -M ${each} -o ${bwa_out}${each%.bam}.stampy.sam
#${stampy_soft}stampy.py -g ptg -h ptg -t4 --bamkeepgoodreads -M ${each%.SE.bam}.PE.bam -o ${bwa_out}${each%.SE.bam}.PE.stampy.sam
#done

#rm ptg*
#${stampy_soft}stampy.py -G ptg ${refPTM}
#${stampy_soft}stampy.py -g ptg -H ptg

#for each in *PTM.SE.bam
#do
#echo ${each}
#${stampy_soft}stampy.py -g ptg -h ptg -t4 --bamkeepgoodreads -M ${each} -o ${bwa_out}${each%.bam}.stampy.sam
#${stampy_soft}stampy.py -g ptg -h ptg -t4 --bamkeepgoodreads -M ${each%.SE.bam}.PE.bam -o ${bwa_out}${each%.SE.bam}.PE.stampy.sam
#done

######### Don't merge PTT and PTM bams before stampy; stampy chooses first best match
#######rm ptg*
#########${stampy_soft}stampy.py -G ptg ${merged_genome}
########${stampy_soft}stampy.py -g ptg -H ptg
#######for each in *PTMPTT.SE.bam
########do
########echo ${each}
########${stampy_soft}stampy.py -g ptg -h ptg -t4 --bamkeepgoodreads -M ${each} -o ${out_dir}${each%.bam}.stampy.sam
########${stampy_soft}stampy.py -g ptg -h ptg -t4 --bamkeepgoodreads -M ${each%.SE.bam}.PE.bam -o ${out_dir}${each%.SE.bam}.PE.stampy.sam
########done


cd ${bwa_out}
#for each in *stampy.sam
#do
#echo ${each}
#${samtools_soft}samtools flagstat ${each} > ${flag_out}${each}.stats
#done

module unload python/2.7.13

##########################################################
echo "Samtools: Sort"#####################################
##########################################################
cd ${bwa_out}
#for each in *stampy.sam
#do
#echo ${each}
#samtools sort -o ${Sorted}${each%.stampy.sam}.sorted.bam -@ 4 ${each}
### stampy depth stats
#samtools depth -a ${Sorted}${each%.stampy.sam}.sorted.bam > ${Depth_dir}${each}.stats
#done

##########################################################
echo "Samtools: Merge"####################################
##########################################################
cd ${Sorted}

#for each in *PTM.PE.sorted.bam
#do
#echo ${each}
#samtools merge ${each%.PTM.PE.sorted.bam}.PTMPTT.merged.bam \
#${each} ${each%.PE.sorted.bam}.SE.sorted.bam \
#${each%.PTM.PE.sorted.bam}.PTT.PE.sorted.bam ${each%.PTM.PE.sorted.bam}.PTT.SE.sorted.bam
#done

##########################################################
echo "Picard: ReadGroup"##################################
##########################################################
#for each in *.merged.bam
#do
#echo ${each}
#var=`samtools view ${each} | head -n 1 | cut -f1 | cut -d ":" -f 3,4`
#java -jar /data/biosoftware/Picard/Picard/picard.jar AddOrReplaceReadGroups \
 #      I=${each} \
  #     O=${each%.merged.bam}.read.bam \
   #    RGID="$var" \
    #   RGLB=lb1 \
     #  RGPL=illumina \
      # RGPU=unit1 \
       #RGSM=${each%.merged.bam}
#samtools index ${each%.merged.bam}.read.bam
#done


#########################################################################################################
echo "GRIDSS: Interchromosomal Translocations/recomb sites & other SVs"##################################
#########################################################################################################
module load R/3.5.3
module load java/x64/8u121

####create a list of isolates and files for gridss
#declare -a arrRG
#declare -a arrIso
#for file in *.PTMPTT.read.bam
#do
 #   arrRG=(${arrRG[*]} "$file")
  #  arrIso=(${arrIso[*]} "${file%.PTMPTT.read.bam},")
#done

#echo ${#arrRG[@]}
#echo "${arrRG[*]}"

#echo ${#arrIso[@]}
#echo "${arrIso[*]}"

#echo "${arrRG[*]}" >Files

#echo "${arrIso[*]}" >List
#sed 's/ //g'  List|sed 's/.$//' >isoList


###/data/biosoftware/gridss/gridss/gridss.sh --reference ${merged_genome} --output PTTxPTMhybrid.gridss.vcf.gz \
###--assembly gridss.assembly.bam --threads 4 --jar /data/biosoftware/gridss/gridss/gridss.jar --workingdir ${gridss} \
###--jvmheap 25g --steps All --maxcoverage 50000 \
###--labels echo "$(cat isoList)" echo "${arrRG[*]}"


#export LC_ALL=C
#/data/biosoftware/gridss/gridss/gridss.sh --reference ${merged_genome} --output PTTxPTMhybrid.gridss.vcf.gz --assembly gridss.assembly.bam \
#--threads 4 --jar /data/biosoftware/gridss/gridss/gridss.jar --workingdir ${gridss} --jvmheap 25g --steps All --maxcoverage 50000 --picardoptions VALIDATION_STRINGENCY=LENIENT \
#--labels 100,101,102,103,104,105,106,107,108,109,10,110,111,112,113,114,115,116,117,118,119,11,120,12,13,14,15,16,17,18,19,1,20,21,22,23,24,25,26,27,28,29,2,30,31,32,33,34,35,36,37,38,39,3,40,41,42,43,44,45,46,47,48,49,4,50,51,52,53,54,55,56,57,58,59,5,60,61,62,63,64,65,66,67,68,69,6,70,72,73,74,75,76,77,78,79b,79,7,80,81,82,83,84,85,86,87,88,89,8,90,91,92,93,94,95,96,97,98,99,9 100.PTMPTT.read.bam 101.PTMPTT.read.bam 102.PTMPTT.read.bam 103.PTMPTT.read.bam 104.PTMPTT.read.bam 105.PTMPTT.read.bam 106.PTMPTT.read.bam 107.PTMPTT.read.bam 108.PTMPTT.read.bam 109.PTMPTT.read.bam 10.PTMPTT.read.bam 110.PTMPTT.read.bam 111.PTMPTT.read.bam 112.PTMPTT.read.bam 113.PTMPTT.read.bam 114.PTMPTT.read.bam 115.PTMPTT.read.bam 116.PTMPTT.read.bam 117.PTMPTT.read.bam 118.PTMPTT.read.bam 119.PTMPTT.read.bam 11.PTMPTT.read.bam 120.PTMPTT.read.bam 12.PTMPTT.read.bam 13.PTMPTT.read.bam 14.PTMPTT.read.bam 15.PTMPTT.read.bam 16.PTMPTT.read.bam 17.PTMPTT.read.bam 18.PTMPTT.read.bam 19.PTMPTT.read.bam 1.PTMPTT.read.bam 20.PTMPTT.read.bam 21.PTMPTT.read.bam 22.PTMPTT.read.bam 23.PTMPTT.read.bam 24.PTMPTT.read.bam 25.PTMPTT.read.bam 26.PTMPTT.read.bam 27.PTMPTT.read.bam 28.PTMPTT.read.bam 29.PTMPTT.read.bam 2.PTMPTT.read.bam 30.PTMPTT.read.bam 31.PTMPTT.read.bam 32.PTMPTT.read.bam 33.PTMPTT.read.bam 34.PTMPTT.read.bam 35.PTMPTT.read.bam 36.PTMPTT.read.bam 37.PTMPTT.read.bam 38.PTMPTT.read.bam 39.PTMPTT.read.bam 3.PTMPTT.read.bam 40.PTMPTT.read.bam 41.PTMPTT.read.bam 42.PTMPTT.read.bam 43.PTMPTT.read.bam 44.PTMPTT.read.bam 45.PTMPTT.read.bam 46.PTMPTT.read.bam 47.PTMPTT.read.bam 48.PTMPTT.read.bam 49.PTMPTT.read.bam 4.PTMPTT.read.bam 50.PTMPTT.read.bam 51.PTMPTT.read.bam 52.PTMPTT.read.bam 53.PTMPTT.read.bam 54.PTMPTT.read.bam 55.PTMPTT.read.bam 56.PTMPTT.read.bam 57.PTMPTT.read.bam 58.PTMPTT.read.bam 59.PTMPTT.read.bam 5.PTMPTT.read.bam 60.PTMPTT.read.bam 61.PTMPTT.read.bam 62.PTMPTT.read.bam 63.PTMPTT.read.bam 64.PTMPTT.read.bam 65.PTMPTT.read.bam 66.PTMPTT.read.bam 67.PTMPTT.read.bam 68.PTMPTT.read.bam 69.PTMPTT.read.bam 6.PTMPTT.read.bam 70.PTMPTT.read.bam 72.PTMPTT.read.bam 73.PTMPTT.read.bam 74.PTMPTT.read.bam 75.PTMPTT.read.bam 76.PTMPTT.read.bam 77.PTMPTT.read.bam 78.PTMPTT.read.bam 79b.PTMPTT.read.bam 79.PTMPTT.read.bam 7.PTMPTT.read.bam 80.PTMPTT.read.bam 81.PTMPTT.read.bam 82.PTMPTT.read.bam 83.PTMPTT.read.bam 84.PTMPTT.read.bam 85.PTMPTT.read.bam 86.PTMPTT.read.bam 87.PTMPTT.read.bam 88.PTMPTT.read.bam 89.PTMPTT.read.bam 8.PTMPTT.read.bam 90.PTMPTT.read.bam 91.PTMPTT.read.bam 92.PTMPTT.read.bam 93.PTMPTT.read.bam 94.PTMPTT.read.bam 95.PTMPTT.read.bam 96.PTMPTT.read.bam 97.PTMPTT.read.bam 98.PTMPTT.read.bam 99.PTMPTT.read.bam 9.PTMPTT.read.bam

##########################################################
echo "GATK: Haplotype Caller"#############################
##########################################################
cd ${Sorted}
for each in *.read.bam
do

#samtools index $each
/data/biosoftware/GATK/gatk-4.1.4.1/gatk --java-options "-Xmx4g" HaplotypeCaller \
   -R ${merged_genome} \
   -I ${each} \
   -ERC BP_RESOLUTION \
   -ploidy 1 \
   -O ${snps}${each%.read.bam}.vcf.gz

done

##########################################################
echo "GATK: CombineGVCFs"#################################
##########################################################
cd $snps
##sed 's/--bam/--variant/g'  aligned/sorted/mantaList|sed 's/read.bam/vcf.gz/g' >vcfList
gatk CombineGVCFs \
   -R ${merged_genome} -LE true \
--variant 100.PTMPTT.vcf.gz \
--variant 101.PTMPTT.vcf.gz \
--variant 102.PTMPTT.vcf.gz \
--variant 103.PTMPTT.vcf.gz \
--variant 104.PTMPTT.vcf.gz \
--variant 105.PTMPTT.vcf.gz \
--variant 106.PTMPTT.vcf.gz \
--variant 107.PTMPTT.vcf.gz \
--variant 108.PTMPTT.vcf.gz \
--variant 109.PTMPTT.vcf.gz \
--variant 10.PTMPTT.vcf.gz \
--variant 110.PTMPTT.vcf.gz \
--variant 111.PTMPTT.vcf.gz \
--variant 112.PTMPTT.vcf.gz \
--variant 113.PTMPTT.vcf.gz \
--variant 114.PTMPTT.vcf.gz \
--variant 115.PTMPTT.vcf.gz \
--variant 116.PTMPTT.vcf.gz \
--variant 117.PTMPTT.vcf.gz \
--variant 118.PTMPTT.vcf.gz \
--variant 119.PTMPTT.vcf.gz \
--variant 11.PTMPTT.vcf.gz \
--variant 120.PTMPTT.vcf.gz \
--variant 12.PTMPTT.vcf.gz \
--variant 13.PTMPTT.vcf.gz \
--variant 14.PTMPTT.vcf.gz \
--variant 15.PTMPTT.vcf.gz \
--variant 16.PTMPTT.vcf.gz \
--variant 17.PTMPTT.vcf.gz \
--variant 18.PTMPTT.vcf.gz \
--variant 19.PTMPTT.vcf.gz \
--variant 1.PTMPTT.vcf.gz \
--variant 20.PTMPTT.vcf.gz \
--variant 21.PTMPTT.vcf.gz \
--variant 22.PTMPTT.vcf.gz \
--variant 23.PTMPTT.vcf.gz \
--variant 24.PTMPTT.vcf.gz \
--variant 25.PTMPTT.vcf.gz \
--variant 26.PTMPTT.vcf.gz \
--variant 27.PTMPTT.vcf.gz \
--variant 28.PTMPTT.vcf.gz \
--variant 29.PTMPTT.vcf.gz \
--variant 2.PTMPTT.vcf.gz \
--variant 30.PTMPTT.vcf.gz \
--variant 31.PTMPTT.vcf.gz \
--variant 32.PTMPTT.vcf.gz \
--variant 33.PTMPTT.vcf.gz \
--variant 34.PTMPTT.vcf.gz \
--variant 35.PTMPTT.vcf.gz \
--variant 36.PTMPTT.vcf.gz \
--variant 37.PTMPTT.vcf.gz \
--variant 38.PTMPTT.vcf.gz \
--variant 39.PTMPTT.vcf.gz \
--variant 3.PTMPTT.vcf.gz \
--variant 40.PTMPTT.vcf.gz \
--variant 41.PTMPTT.vcf.gz \
--variant 42.PTMPTT.vcf.gz \
--variant 43.PTMPTT.vcf.gz \
--variant 44.PTMPTT.vcf.gz \
--variant 45.PTMPTT.vcf.gz \
--variant 46.PTMPTT.vcf.gz \
--variant 47.PTMPTT.vcf.gz \
--variant 48.PTMPTT.vcf.gz \
--variant 49.PTMPTT.vcf.gz \
--variant 4.PTMPTT.vcf.gz \
--variant 50.PTMPTT.vcf.gz \
--variant 51.PTMPTT.vcf.gz \
--variant 52.PTMPTT.vcf.gz \
--variant 53.PTMPTT.vcf.gz \
--variant 54.PTMPTT.vcf.gz \
--variant 55.PTMPTT.vcf.gz \
--variant 56.PTMPTT.vcf.gz \
--variant 57.PTMPTT.vcf.gz \
--variant 58.PTMPTT.vcf.gz \
--variant 59.PTMPTT.vcf.gz \
--variant 5.PTMPTT.vcf.gz \
--variant 60.PTMPTT.vcf.gz \
--variant 61.PTMPTT.vcf.gz \
--variant 62.PTMPTT.vcf.gz \
--variant 63.PTMPTT.vcf.gz \
--variant 64.PTMPTT.vcf.gz \
--variant 65.PTMPTT.vcf.gz \
--variant 66.PTMPTT.vcf.gz \
--variant 67.PTMPTT.vcf.gz \
--variant 68.PTMPTT.vcf.gz \
--variant 69.PTMPTT.vcf.gz \
--variant 6.PTMPTT.vcf.gz \
--variant 70.PTMPTT.vcf.gz \
--variant 72.PTMPTT.vcf.gz \
--variant 73.PTMPTT.vcf.gz \
--variant 74.PTMPTT.vcf.gz \
--variant 75.PTMPTT.vcf.gz \
--variant 76.PTMPTT.vcf.gz \
--variant 77.PTMPTT.vcf.gz \
--variant 78.PTMPTT.vcf.gz \
--variant 79b.PTMPTT.vcf.gz \
--variant 79.PTMPTT.vcf.gz \
--variant 7.PTMPTT.vcf.gz \
--variant 80.PTMPTT.vcf.gz \
--variant 81.PTMPTT.vcf.gz \
--variant 82.PTMPTT.vcf.gz \
--variant 83.PTMPTT.vcf.gz \
--variant 84.PTMPTT.vcf.gz \
--variant 85.PTMPTT.vcf.gz \
--variant 86.PTMPTT.vcf.gz \
--variant 87.PTMPTT.vcf.gz \
--variant 88.PTMPTT.vcf.gz \
--variant 89.PTMPTT.vcf.gz \
--variant 8.PTMPTT.vcf.gz \
--variant 90.PTMPTT.vcf.gz \
--variant 91.PTMPTT.vcf.gz \
--variant 92.PTMPTT.vcf.gz \
--variant 93.PTMPTT.vcf.gz \
--variant 94.PTMPTT.vcf.gz \
--variant 95.PTMPTT.vcf.gz \
--variant 96.PTMPTT.vcf.gz \
--variant 97.PTMPTT.vcf.gz \
--variant 98.PTMPTT.vcf.gz \
--variant 99.PTMPTT.vcf.gz \
--variant 9.PTMPTT.vcf.gz \
-O hybrids.g.vcf.gz

##########################################################
echo "GATK: Call Genotypes"###############################
##########################################################

java -jar /data/biosoftware/GATK/GATK/GenomeAnalysisTK.jar \
-T GenotypeGVCFs \
-R $merged_genome \
--variant hybrids.g.vcf.gz \
-o hybrids.geno.vcf.gz

##########################################################
echo "GATK: Hardfiltering"################################
##########################################################
gatk VariantFiltration \
   -R $merged_genome \
   -V hybrids.geno.vcf.gz \
   -O hybrids.flt.vcf \
   --filter-expression "QD < 2.0 || DP < 8.0 || MQ < 40.0 || MQRankSum < -12.5 || ReadPosRankSum < -8.0" \
   --filter-name "INFO" \
   --genotype-filter-expression "DP < 3 || GT = 1 " \
   --genotype-filter-name "LowDepth"
done

##########################################################
echo "GATK: Remove loci based on missing info"############
##########################################################
gatk SelectVariants \
	-V hybrids.flt.vcf \
	--set-filtered-gt-to-nocall \
	-O hybrids.fltnocall.vcf





##vcftools --remove names.txt --vcf FilteredNewNoCall.vcf --out FilteredRM --recode --recode-INFO-all

##vcftools --max-missing 0.5 --vcf FilteredRM.recode.vcf --out FullyFiltered --recode --recode-INFO-all
##vcftools --max-missing 0.5 --vcf FilteredNewNoCall.vcf --out FullyFiltered --recode --recode-INFO-all
vcftools --max-missing 0.9 --vcf FilteredNewNoCall.vcf --out FullyFiltered --recode --recode-INFO-all

gatk SelectVariants \
     -R $merged_genome \
     -V FullyFiltered.recode.vcf \
     --exclude-filtered -O ExcludeFilters.vcf

gatk SelectVariants \
     -R $merged_genome \
     -V ExcludeFilters.vcf \
     --exclude-non-variants -O VariantOnly.vcf

##########################################################
echo "VCFtools: Missing INFO"#############################
##########################################################

vcftools --missing-indv --vcf Genotype.vcf --out missRAW
vcftools --missing-indv --vcf FilteredNewNoCall.vcf --out missHF
vcftools --missing-indv --vcf FilteredRM.recode.vcf --out misssampleRem
vcftools --missing-indv --vcf FullyFiltered.recode.vcf misspossRem
vcftools --missing-indv --vcf ExcludeFilters.vcf --out missFlagout
vcftools --missing-indv --vcf VariantOnly.vcf --out missVaronly

#########################################################################################################
echo "parsnp: recombination blocks--align PTT and PTM genomes and F1"####################################
#########################################################################################################
###vcf to fasta





###parsnp multiple fastas
