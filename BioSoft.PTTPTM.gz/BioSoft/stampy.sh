#!/bin/bash
#
#  submit by  sbatch stampy.sh
#
#  specify the job name
#SBATCH --job-name=stampy
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=30:00:00
#  maximum requested memory
#SBATCH --mem=10G
#  write std out and std error to these files
#SBATCH --error=stampy.%J.err
#SBATCH --output=stampy.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#  add your code here:

stampy_soft=/data/biosoftware/stampy/stampy/
samtools_soft=/data/biosoftware/samtools/samtools-1.9/
bwa_input=/mnt/beegfs/yuzon/aligned/
out_dir=/mnt/beegfs/yuzon/aligned/stampy/
Ref=/mnt/beegfs/yuzon/references/0-1_assembly.v14.fa
flag_out=/mnt/beegfs/yuzon/aligned/stampy/flag/

cd ${bwa_input}

module load python/2.7.13

make BAM
for each in ${bwa_input}*.sam
do
${samtools_soft}samtools view -S -b ${each} > ${each%.sam}.bam  
done

stampy

${stampy_soft}stampy.py -G ptg ${Ref}

${stampy_soft}stampy.py -g ptg -H ptg

for each in *P_.bam
do
echo ${each}
${stampy_soft}stampy.py -g ptg -h ptg -t4 --bamkeepgoodreads -M ${each} -o ${out_dir}${each%.bam}.stampy.sam
done

cd ${out_dir}
for each in *.sam
do
echo ${each}
${samtools_soft}samtools flagstat ${each} > ${flag_out}${each}.stats
done
