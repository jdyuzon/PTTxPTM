#!/bin/bash
#
#  submit by  sbatch samtools.sh
#
#  specify the job name
#SBATCH --job-name=nucmer
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=900:00:00
#  maximum requested memory
#SBATCH --mem=30G
#  write std out and std error to these files
#SBATCH --error=nucmer.%J.err
#SBATCH --output=nucmer.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

########################################################    
###################### Genomes #########################
######################################################## 

refgenome=/home/yuzon/references/hybrid_references/PTT_0-1_assembly.v14.fa
qrygenome=/home/yuzon/references/hybrid_references/PTM_FGOB10Ptm-1_assembly.v7.fasta
prefix=PTTvsPTM
MAT=/home/yuzon/references/MATloci_sequences.fasta

genomecompare=/home/yuzon/PTTxPTMtest/PTTxPTMcompare/
mkdir ${genomecompare}
mkdir ${genomecompare}/PTT_repeat
mkdir ${genomecompare}/PTM_repeat
cd ${genomecompare}

########################################################
######## Repeat Modeler and Repeat Masker ##############
######################################################## 

##### Repeat Modeler
#/data/biosoftware/RepeatModeler/RepeatModelerCrossMatch/RepeatModeler-open-1.0.11/BuildDatabase \
#-name ${genomecompare}PTT_repeat/PTT.DB -engine ncbi ${refgenome} 

#/data/biosoftware/RepeatModeler/RepeatModelerCrossMatch/RepeatModeler-open-1.0.11/RepeatModeler \
#-database ${genomecompare}PTT_repeat/PTT.DB -engine ncbi -pa 16

#/data/biosoftware/RepeatModeler/RepeatModelerCrossMatch/RepeatModeler-open-1.0.11/BuildDatabase \
#-name ${genomecompare}PTM_repeat/PTM.DB -engine ncbi ${qrygenome}

#/data/biosoftware/RepeatModeler/RepeatModelerCrossMatch/RepeatModeler-open-1.0.11/RepeatModeler \
#-database ${genomecompare}PTM_repeat/PTM.DB -engine ncbi -pa 16

##### Repeat Masker
#cd ${genomecompare}PTT_repeat
#ln -s ${genomecompare}PTT_repeat/RM_5987.FriMar61212222020/consensi.fa.classified
#/data/biosoftware/RepeatMasker/RepeatMasker/RepeatMasker -pa 16 -gff -lib ${genomecompare}PTT_repeat/RM_5987.FriMar61212222020/consensi.fa.classified ${refgenome}

#cd ${genomecompare}PTM_repeat
#ln -s ${genomecompare}PTM_repeat/RM_1074.TueMar100815222020/consensi.fa.classified
#/data/biosoftware/RepeatMasker/RepeatMasker/RepeatMasker -pa 16 -gff -lib ${genomecompare}PTM_repeat/RM_1074.TueMar100815222020/consensi.fa.classified ${qrygenome}


########################################################    
############### Nucmer: Genome Compare #################
######################################################## 

echo ###nuclear genome: only chromosomes, no contigs (too many repeats) ######
#samtools faidx ${refgenome}.masked chrPTT_1 chrPTT_2 chrPTT_3 chrPTT_4 chrPTT_5 chrPTT_6 chrPTT_7 chrPTT_8 chrPTT_9 chrPTT_10 chrPTT_11 chrPTT_12 > PTT_nuclearchr.fa.masked
#samtools faidx ${qrygenome}.masked chrPTM_1 chrPTM_2 chrPTM_3 chrPTM_4 chrPTM_5 chrPTM_6 chrPTM_7 chrPTM_8 chrPTM_9 chrPTM_10 chrPTM_11 chrPTM_12 > PTM_nuclearchr.fa.masked

echo ###mitochondrial genome######
#samtools faidx ${refgenome}.masked 0-1_contig_m86 > PTT_mitochondria.fa.masked
#samtools faidx ${qrygenome}.masked mitochondrial_contig > PTM_mitochondria.fa.masked

echo ###compare nuclear genome######
#nucmer -mum -mincluster 100 -minmatch 50 --prefix=${genomecompare}${prefix}.nuclearchr.masked PTT_nuclearchr.fa.masked PTM_nuclearchr.fa.masked
#delta-filter -r -q ${genomecompare}${prefix}.nuclearchr.masked.delta >${genomecompare}${prefix}.nuclearchr.masked.filter
#show-snps -Clr ${genomecompare}${prefix}.nuclearchr.masked.filter > ${genomecompare}${prefix}.nuclearchr.masked.snps
#mummerplot ${genomecompare}${prefix}.nuclearchr.masked.filter --png --SNP --color -p ${genomecompare}${prefix}.nuclearchr.masked
#show-coords ${genomecompare}${prefix}.nuclearchr.masked.delta > ${genomecompare}${prefix}.nuclearchr.masked.show-coords
#grep "chrPTT" ${genomecompare}${prefix}.nuclearchr.masked.show-coords \
#|awk '{print $12 "\t" $13 "\t" $1 "\t" $2 "\t" $4 "\t" $5}'>${genomecompare}${prefix}.nuclearchr.masked.show-coords.txt

echo ###compare mitochondrial genome#######
#nucmer -mum -mincluster 100 -minmatch 50 --prefix=${genomecompare}${prefix}.mitochondria.masked PTT_mitochondria.fa.masked PTM_mitochondria.fa.masked
#delta-filter -r -q ${genomecompare}${prefix}.mitochondria.masked.delta >${genomecompare}${prefix}.mitochondria.masked.filter
#show-snps -Clr ${genomecompare}${prefix}.mitochondria.masked.filter > ${genomecompare}${prefix}.mitochondria.masked.snps
#mummerplot ${genomecompare}${prefix}.mitochondria.masked.filter --png --SNP --color -p ${genomecompare}${prefix}.masked.mitochondria
#show-coords ${genomecompare}${prefix}.mitochondria.masked.delta > ${genomecompare}${prefix}.mitochondria.masked.show-coords
#grep "m86" ${genomecompare}${prefix}.mitochondria.masked.show-coords \
#|awk '{print $12 "\t" $13 "\t" $1 "\t" $2 "\t" $4 "\t" $5}'>${genomecompare}${prefix}.mitochondria.masked.show-coords.txt

#cat ${genomecompare}${prefix}.nuclearchr.masked.show-coords.txt ${genomecompare}${prefix}.mitochondria.masked.show-coords.txt \
#> ${genomecompare}${prefix}.nuclearchrmitochondria.masked.show-coords.txt


echo ### Identiyf MAT Loci #######
nucmer -mum -mincluster 100 -minmatch 50 --prefix=${genomecompare}PTT.MAT PTT_nuclearchr.fa.masked $MAT
delta-filter -r -q ${genomecompare}PTT.MAT.delta >${genomecompare}PTT.MAT.filter
show-snps -Clr ${genomecompare}PTT.MAT.filter > ${genomecompare}PTT.MAT.snps
show-coords ${genomecompare}PTT.MAT.delta > ${genomecompare}PTT.MAT.show-coords
grep "chrPTT" ${genomecompare}PTT.MAT.show-coords \
|awk '{print $12 "\t" $13 "\t" $1 "\t" $2 "\t" $4 "\t" $5}'>${genomecompare}PTT.MAT.show-coords.txt


nucmer -mum -mincluster 100 -minmatch 50 --prefix=${genomecompare}PTM.MAT PTM_nuclearchr.fa.masked $MAT
delta-filter -r -q ${genomecompare}PTM.MAT.delta >${genomecompare}PTM.MAT.filter
show-snps -Clr ${genomecompare}PTM.MAT.filter > ${genomecompare}PTM.MAT.snps
show-coords ${genomecompare}PTM.MAT.delta > ${genomecompare}PTM.MAT.show-coords
grep "chrPTT" ${genomecompare}PTM.MAT.show-coords \
|awk '{print $12 "\t" $13 "\t" $1 "\t" $2 "\t" $4 "\t" $5}'>${genomecompare}PTM.MAT.show-coords.txt
