#!/bin/bash

#
#  submit by  sbatch Haplotype_caller.sh
#
#  specify the job name
#SBATCH --job-name=PTTxPTMhybrid
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=90:00:00
#  maximum requested memory
#SBATCH --mem=70G
#  write std out and std error to these files
#SBATCH --error=PTTxPTMhybrid.%J.err
#SBATCH --output=PTTxPTMhybrid.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

########################################################################
refPTT=/home/yuzon/references/hybrid_references/PTT_0-1_assembly.v14.fa
refPTM=/home/yuzon/references/hybrid_references/PTM_FGOB10Ptm-1_assembly.v7.fasta
snps=/home/yuzon/PTTxPTMtest/SNPcalling/
parsnp_qry=/home/yuzon/PTTxPTMtest/SNPcalling/parsnp_qry/
parsnp_out=/home/yuzon/PTTxPTMtest/SNPcalling/parsnp_out/

#run bash to submit parallel jobs on the cluster
### example: sbatch SL_PTTxPTMhybrid.parallel.sh 100 /home/yuzon/PTTxPTMtest/
########################################################################

#sbatch SL_PTTxPTMhybrid.parallel.sh 1 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 2 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 3 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 4 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 5 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 6 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 7 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 8 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 9 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 10 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 11 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 12 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 13 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 14 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 15 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 16 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 17 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 18 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 19 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 20 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 21 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 22 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 23 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 24 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 25 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 26 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 27 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 28 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 29 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 30 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 31 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 32 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 33 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 34 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 35 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 36 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 37 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 38 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 39 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 40 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 41 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 42 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 43 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 44 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 45 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 46 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 47 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 48 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 49 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 50 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 51 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 52 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 53 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 54 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 55 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 56 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 57 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 58 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 59 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 60 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 61 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 62 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 63 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 64 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 65 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 66 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 67 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 68 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 69 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 70 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 72 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 73 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 74 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 75 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 76 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 77 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 78 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 79 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 79b /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 80 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 81 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 82 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 83 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 84 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 85 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 86 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 87 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 88 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 89 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 90 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 91 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 92 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 93 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 94 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 95 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 96 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 97 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 98 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 99 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 100 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 101 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 102 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 103 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 104 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 105 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 106 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 107 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 108 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 109 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 110 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 111 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 112 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 113 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 114 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 115 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 116 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 117 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 118 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 119 /home/yuzon/PTTxPTMtest/
#sbatch SL_PTTxPTMhybrid.parallel.sh 120 /home/yuzon/PTTxPTMtest/

##########################################
cd SNPcalling 

bcftools merge *PTMPTT.flt.vcf -o PTM.PTT.flt.vcf

##########################################
cd SNPcalling
cat \
1.PTMPTT.flt.bed \
2.PTMPTT.flt.bed \
3.PTMPTT.flt.bed \
4.PTMPTT.flt.bed \
5.PTMPTT.flt.bed \
6.PTMPTT.flt.bed \
7.PTMPTT.flt.bed \
8.PTMPTT.flt.bed \
9.PTMPTT.flt.bed \
10.PTMPTT.flt.bed \
11.PTMPTT.flt.bed \
12.PTMPTT.flt.bed \
13.PTMPTT.flt.bed \
14.PTMPTT.flt.bed \
15.PTMPTT.flt.bed \
16.PTMPTT.flt.bed \
17.PTMPTT.flt.bed \
18.PTMPTT.flt.bed \
19.PTMPTT.flt.bed \
20.PTMPTT.flt.bed \
21.PTMPTT.flt.bed \
22.PTMPTT.flt.bed \
23.PTMPTT.flt.bed \
24.PTMPTT.flt.bed \
25.PTMPTT.flt.bed \
26.PTMPTT.flt.bed \
27.PTMPTT.flt.bed \
28.PTMPTT.flt.bed \
29.PTMPTT.flt.bed \
30.PTMPTT.flt.bed \
31.PTMPTT.flt.bed \
32.PTMPTT.flt.bed \
33.PTMPTT.flt.bed \
34.PTMPTT.flt.bed \
35.PTMPTT.flt.bed \
36.PTMPTT.flt.bed \
37.PTMPTT.flt.bed \
38.PTMPTT.flt.bed \
39.PTMPTT.flt.bed \
40.PTMPTT.flt.bed \
41.PTMPTT.flt.bed \
42.PTMPTT.flt.bed \
43.PTMPTT.flt.bed \
44.PTMPTT.flt.bed \
45.PTMPTT.flt.bed \
46.PTMPTT.flt.bed \
47.PTMPTT.flt.bed \
48.PTMPTT.flt.bed \
49.PTMPTT.flt.bed \
50.PTMPTT.flt.bed \
51.PTMPTT.flt.bed \
52.PTMPTT.flt.bed \
53.PTMPTT.flt.bed \
54.PTMPTT.flt.bed \
55.PTMPTT.flt.bed \
56.PTMPTT.flt.bed \
57.PTMPTT.flt.bed \
58.PTMPTT.flt.bed \
59.PTMPTT.flt.bed \
60.PTMPTT.flt.bed \
61.PTMPTT.flt.bed \
62.PTMPTT.flt.bed \
63.PTMPTT.flt.bed \
64.PTMPTT.flt.bed \
65.PTMPTT.flt.bed \
66.PTMPTT.flt.bed \
67.PTMPTT.flt.bed \
68.PTMPTT.flt.bed \
69.PTMPTT.flt.bed \
70.PTMPTT.flt.bed \
72.PTMPTT.flt.bed \
73.PTMPTT.flt.bed \
74.PTMPTT.flt.bed \
75.PTMPTT.flt.bed \
76.PTMPTT.flt.bed \
77.PTMPTT.flt.bed \
78.PTMPTT.flt.bed \
79.PTMPTT.flt.bed \
79b.PTMPTT.flt.bed \
80.PTMPTT.flt.bed \
81.PTMPTT.flt.bed \
82.PTMPTT.flt.bed \
83.PTMPTT.flt.bed \
84.PTMPTT.flt.bed \
85.PTMPTT.flt.bed \
86.PTMPTT.flt.bed \
87.PTMPTT.flt.bed \
88.PTMPTT.flt.bed \
89.PTMPTT.flt.bed \
90.PTMPTT.flt.bed \
91.PTMPTT.flt.bed \
92.PTMPTT.flt.bed \
93.PTMPTT.flt.bed \
94.PTMPTT.flt.bed \
95.PTMPTT.flt.bed \
96.PTMPTT.flt.bed \
97.PTMPTT.flt.bed \
98.PTMPTT.flt.bed \
99.PTMPTT.flt.bed \
100.PTMPTT.flt.bed \
101.PTMPTT.flt.bed \
102.PTMPTT.flt.bed \
103.PTMPTT.flt.bed \
104.PTMPTT.flt.bed \
105.PTMPTT.flt.bed \
106.PTMPTT.flt.bed \
107.PTMPTT.flt.bed \
108.PTMPTT.flt.bed \
109.PTMPTT.flt.bed \
110.PTMPTT.flt.bed \
111.PTMPTT.flt.bed \
112.PTMPTT.flt.bed \
113.PTMPTT.flt.bed \
114.PTMPTT.flt.bed \
115.PTMPTT.flt.bed \
116.PTMPTT.flt.bed \
117.PTMPTT.flt.bed \
118.PTMPTT.flt.bed \
119.PTMPTT.flt.bed \
120.PTMPTT.flt.bed \
|sed 's/0-1_contig_m86/mitochondria/g' \
|sed 's/0-1_contig_/contig/g' \
|sed 's/PTT_//g' | awk -v OFS='\t'  '{ if ($4 == "-") {$4 = "PTM"}; print }' \
|awk -v OFS='\t'  '{ if ($4 == "+") {$4 = "PTT"}; print }' \
|awk -v OFS='\t' '{print $1, $2, $3, $4, $5, $6, $7}' \
>all.PTMPTT.flt.bed
grep -v "contig" all.PTMPTT.flt.bed  >all.PTMPTT.flt.nuclmito.bed

awk -v OFS='\t' '{print $2, $3, $4, $5, $6, $7, $1}' all.PTMPTT.flt.bed| bedtools intersect -a stdin -b matloci.bed -nonamecheck> mat
grep 'm86\|mito' all.PTMPTT.flt.nuclmito.bed|awk -v OFS='\t' '{print $0}'|cat mat - >all.matmito.bed

##########Intermediate files#################
cd nucmer
for entry in *common_uniq.bed
do
        awk -v variable="$entry" '{print $0 "\t" variable} ' $entry| sed 's/.common_uniq.bed//g' >$entry.tmp
done

cat *common_uniq.bed.tmp|grep -v "all" >all.common_uniq.bed
bedtools intersect -a all.common_uniq.bed -b matloci.bed -nonamecheck > test
grep 'mito\|m86' all.common_uniq.bed|cat test - >all.common_uniq.matmito.bed

sed 's/PTT_//g' all.common_uniq.bed| sed 's/0-1_contig_m86/mitochondria/g' >test
mv test all.common_uniq.bed
sed 's/PTT_//g' all.common_uniq.matmito.bed| sed 's/0-1_contig_m86/mitochondria/g' >test
mv test all.common_uniq.matmito.bed

############Block files#####################
for entry in *common_unique.blocks.bed
do
        awk -v variable="$entry" '{print $0 "\t" variable} ' $entry| sed 's/.common_unique.blocks.bed//g' >$entry.tmp
done


cat *.common_unique.blocks.bed.tmp |grep -v "all" >all.common_unique.blocks.bed
bedtools intersect -a all.common_unique.blocks.bed -b matloci.bed -nonamecheck> test
grep 'mito\|m86' all.common_unique.blocks.bed|cat test - >all.common_unique.blocks.matmito.bed

mkdir Rplotfiles
cp all.common* Rplotfiles
cp ../all.* Rplotfiles



############# parsnp #################
#/data/biosoftware/harvest/harvest/parsnp -r /home/yuzon/references/parsnp_ref/test.fa  -d  $parsnp_qry -o $parsnp_out
#/data/biosoftware/harvest/harvest/harvesttools -i ${parsnp_out}parsnp.ggr -V ${parsnp_out}parsnp.vcf


cd ..

bcftools merge *PTMPTT.flt.vcf.gz -Ov -o all.PTT.flt.vcf
vcftools --vcf all.PTT.flt.vcf --min-alleles 2 --max-alleles 2 --maf  0.004 --recode --out all.PTT.flt2 --max-missing-count 110

for sample in `bcftools query -l all.PTT.flt2.recode.vcf`
do

vcf-subset --exclude-ref -c $sample all.PTT.flt2.recode.vcf > ${sample}.flt2.vcf
grep -v "#" ${sample}.flt2.vcf|cut -f1,2,10|sed 's/:.*//g' \
|awk -v OFS='\t' '{ if ($4 == "0") {$4 = "PTT"}; print }'\
|awk -v OFS='\t' '{ if ($4 == "1") {$4 = "PTM"}; print }' > $sample.flt3.vcf

done

cat *.flt3.vcf >all.flt3.vcf
