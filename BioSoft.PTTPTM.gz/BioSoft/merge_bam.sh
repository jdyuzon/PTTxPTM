#!/bin/bash
#
#  submit by  sbatch merge.sh
#
#  specify the job name
#SBATCH --job-name=samtools
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=20:00:00
#  maximum requested memory
#SBATCH --mem=10G
#  write std out and std error to these files
#SBATCH --error=sam.%J.err
#SBATCH --output=sam.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#  add your code here:
sorted_dir=/mnt/beegfs/yuzon/aligned/sorted/

cd ${sorted_dir}
mkdir merged
for each in *.sorted.bam
do
echo ${each}
samtools merge ${sorted_dir}merged/${each%.sorted.bam}merged.bam ${each} ${each%.sorted.bam}unassembled.U_1.sorted.bam ${each%sorted.bam}unassembled.U_2.sorted.bam
done

