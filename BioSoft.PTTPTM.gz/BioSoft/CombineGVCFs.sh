#!/bin/bash
#
#  submit by  sbatch Haplotype_caller.sh
#
#  specify the job name
#SBATCH --job-name=GATK
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=90:00:00
#  maximum requested memory
#SBATCH --mem=15G
#  write std out and std error to these files
#SBATCH --error=gatk.%J.err
#SBATCH --output=gatk.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#  add your code here:

cd /home/taliadoros/bwa/stampy/sorted/merged/merged/RGed/index/haplotype_caller/
reff=/home/taliadoros/Reff_gen/0-1_assembly.v14.fa

gatk CombineGVCFs \
   -R $reff \
   --variant FGOH04-Ptt1_P_.g.vcf.gz \
--variant FGOH04-Ptt2_P_.g.vcf.gz \
--variant FGOH04-Ptt3_P_.g.vcf.gz \
--variant FGOH04Ptt-4_P_.g.vcf.gz \
--variant FGOH04-Ptt5_P_.g.vcf.gz \
--variant FGOH04Ptt-6_P_.g.vcf.gz \
--variant FGOH04Ptt-7_P_.g.vcf.gz \
--variant FGOH04Ptt-8_P_.g.vcf.gz \
--variant FGOH04Ptt-9_P_.g.vcf.gz \
--variant FGOH05Ptt-10_P_.g.vcf.gz \
--variant FGOH05-Ptt1_P_.g.vcf.gz \
--variant FGOH05Ptt-2_P_.g.vcf.gz \
--variant FGOH05Ptt-3_P_.g.vcf.gz \
--variant FGOH05Ptt-4_P_.g.vcf.gz \
--variant FGOH05Ptt-5_P_.g.vcf.gz \
--variant FGOH05Ptt-6_P_.g.vcf.gz \
--variant FGOH05-Ptt7_P_.g.vcf.gz \
--variant FGOH05-Ptt8_P_.g.vcf.gz \
--variant FGOH05Ptt-9_P_.g.vcf.gz \
--variant FGOH06Ptt-1_P_.g.vcf.gz \
--variant FGOH06Ptt-3_P_.g.vcf.gz \
--variant FGOH06Ptt-4_P_.g.vcf.gz \
--variant FGOH06Ptt-5_P_.g.vcf.gz \
--variant FGOH06Ptt-6_P_.g.vcf.gz \
--variant FGOH06Ptt-7_P_.g.vcf.gz \
--variant FGOH07Ptt-10_P_.g.vcf.gz \
--variant FGOH07Ptt-1_P_.g.vcf.gz \
--variant FGOH07Ptt-2_P_.g.vcf.gz \
--variant FGOH07Ptt-3_P_.g.vcf.gz \
--variant FGOH07Ptt-4_P_.g.vcf.gz \
--variant FGOH07Ptt-6_P_.g.vcf.gz \
--variant FGOH07Ptt-7_P_.g.vcf.gz \
--variant FGOH07Ptt-9_P_.g.vcf.gz \
--variant LDNH04Ptt-10_P_.g.vcf.gz \
--variant LDNH04Ptt-1_P_.g.vcf.gz \
--variant LDNH04Ptt-2_P_.g.vcf.gz \
--variant LDNH04-Ptt3_P_.g.vcf.gz \
--variant LDNH04Ptt-4_P_.g.vcf.gz \
--variant LDNH04Ptt-5_P_.g.vcf.gz \
--variant LDNH04-Ptt6_P_.g.vcf.gz \
--variant LDNH04Ptt-7_P_.g.vcf.gz \
--variant LDNH04Ptt-8_P_.g.vcf.gz \
--variant LDNH04Ptt-9_P_.g.vcf.gz \
--variant LDNH05-Ptt10_P_.g.vcf.gz \
--variant LDNH05-Ptt1_P_.g.vcf.gz \
--variant LDNH05-Ptt2_P_.g.vcf.gz \
--variant LDNH05Ptt-3_P_.g.vcf.gz \
--variant LDNH05Ptt-4_P_.g.vcf.gz \
--variant LDNH05Ptt-5_P_.g.vcf.gz \
--variant LDNH05-Ptt6_P_.g.vcf.gz \
--variant LDNH05Ptt-7_P_.g.vcf.gz \
--variant LDNH05Ptt-8_P_.g.vcf.gz \
--variant LDNH05-Ptt9_P_.g.vcf.gz \
--variant LDNH06Ptt-10_P_.g.vcf.gz \
--variant LDNH06Ptt-1_P_.g.vcf.gz \
--variant LDNH06Ptt-2_P_.g.vcf.gz \
--variant LDNH06-Ptt3_P_.g.vcf.gz \
--variant LDNH06Ptt-5_P_.g.vcf.gz \
--variant LDNH06Ptt-6_P_.g.vcf.gz \
--variant LDNH06Ptt-8_P_.g.vcf.gz \
--variant LDNH06Ptt-9_P_.g.vcf.gz \
--variant LDNH07Ptt-2_P_.g.vcf.gz \
--variant LDNH07Ptt-3_P_.g.vcf.gz \
--variant LDNH07Ptt-4_P_.g.vcf.gz \
--variant LDNH07Ptt-5_P_.g.vcf.gz \
--variant LDNH07Ptt-7_P_.g.vcf.gz \
--variant LDNH07Ptt-8_P_.g.vcf.gz \
--variant LDNH07Ptt-9_P_.g.vcf.gz \
--variant Mor-CC-1B_P_.g.vcf.gz \
--variant Mor-CC-2B_P_.g.vcf.gz \
--variant Mor-CC-B3_P_.g.vcf.gz \
--variant Mor-CC-B4_P_.g.vcf.gz \
--variant Mor-CC-B5_P_.g.vcf.gz \
--variant Mor-CCS-A1_P_.g.vcf.gz \
--variant Mor-ICS-A1_P_.g.vcf.gz \
--variant Mor-ICS-A2_P_.g.vcf.gz \
--variant Mor-ICS-B1_P_.g.vcf.gz \
--variant Mor-S-27-1_P_.g.vcf.gz \
--variant Mor-SM-10-1_P_.g.vcf.gz \
--variant Mor-SM-13-1_P_.g.vcf.gz \
--variant Mor-SM-13-2_P_.g.vcf.gz \
--variant Mor-SM-2-2_P_.g.vcf.gz \
--variant Mor-SM-23-1_P_.g.vcf.gz \
--variant Mor-SM-24-1_P_.g.vcf.gz \
--variant Mor-SM-25-2_P_.g.vcf.gz \
--variant Mor-SM-25-3_P_.g.vcf.gz \
--variant Mor-SM-26-2_P_.g.vcf.gz \
--variant Mor-SM-29-2_P_.g.vcf.gz \
--variant Mor-SM-3-1_P_.g.vcf.gz \
--variant Mor-SM-34-1_P_.g.vcf.gz \
--variant Mor-SM-34-2_P_.g.vcf.gz \
--variant Mor-SM-36-1_P_.g.vcf.gz \
--variant Mor-SM-36-2_P_.g.vcf.gz \
--variant Mor-SM-36-3_P_.g.vcf.gz \
--variant Mor-SM-36-5_P_.g.vcf.gz \
--variant Mor-SM-39-3_P_.g.vcf.gz \
--variant Mor-SM-39-4_P_.g.vcf.gz \
--variant Mor-SM-40-3_P_.g.vcf.gz \
--variant Mor-SM-41-2_P_.g.vcf.gz \
--variant Mor-SM-42-1_P_.g.vcf.gz \
--variant Mor-SM-42-2_P_.g.vcf.gz \
--variant Mor-SM-42-3_P_.g.vcf.gz \
--variant Mor-SM-43-1_P_.g.vcf.gz \
--variant Mor-SM-43-2_P_.g.vcf.gz \
--variant Mor-SM-44-2_P_.g.vcf.gz \
--variant Mor-SM-44-3_P_.g.vcf.gz \
--variant Mor-SM-45-3_P_.g.vcf.gz \
--variant Mor-SM-46-1_P_.g.vcf.gz \
--variant Mor-SM-46-3_P_.g.vcf.gz \
--variant Mor-SM-49-1_P_.g.vcf.gz \
--variant Mor-SM-50-2_P_.g.vcf.gz \
--variant Mor-SM-53-1_P_.g.vcf.gz \
--variant Mor-SM-8-1_P_.g.vcf.gz \
-O cohort2.g.vcf.gz
