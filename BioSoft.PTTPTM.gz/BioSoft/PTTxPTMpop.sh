#!/bin/bash
#
#  submit by  sbatch Haplotype_caller.sh
#
#  specify the job name
#SBATCH --job-name=PTTxPTMpop
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=90:00:00
#  maximum requested memory
#SBATCH --mem=15G
#  write std out and std error to these files
#SBATCH --error=PTTxPTMpop.%J.err
#SBATCH --output=PTTxPTMpop.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

###########################################################
echo "Software"
###########################################################
##module load java/x64/8u121

trimmo=/data/biosoftware/Trimmomatic/Trimmomatic-0.38/
pear=/data/biosoftware/pear/pear-0.9.10-bin-64/pear-0.9.10-bin-64 
export BBMAPDIR=/data/biosoftware/bbmap/bbmap
bwa_soft=/data/biosoftware/bwa/bwa-0.7.15/
stampy_soft=/data/biosoftware/stampy/stampy/
samtools_soft=/data/biosoftware/samtools/samtools-1.9/
fastqc=/data/biosoftware/FastQC/FastQC/fastqc


##########################################################
echo "Directories"
##########################################################
project=Iranianpop

refPTT=/home/yuzon/references/hybrid_references/PTT_0-1_assembly.v14.fa
refPTM=/home/yuzon/references/hybrid_references/PTM_FGOB10Ptm-1_assembly.v7.fasta
merged_genome=/home/yuzon/references/hybrid_references/merged_genome_PTTxPTM.fasta

Raw_reads=/home/yuzon/raw_reads/${project}/
Raw_fastqc=/home/yuzon/${project}/fastQC/raw_fastqc
trimmed=/home/yuzon/${project}/trimmed/

PEoverlap=/home/yuzon/${project}/trimmed/pear/
Pear_fastqc=/home/yuzon/${project}/fastQC/fastqc_pear
assembled=/home/yuzon/${project}/trimmed/pear/assembled/
unassembled=/home/yuzon/${project}/trimmed/pear/unassembled/
unassembled_fastqc=/home/yuzon/${project}/fastQC/fastqc_unassembled
assembled_fastqc=/home/yuzon/${project}/fastQC/fastqc_assembled

markdup=/home/yuzon/${project}/trimmed/prinseq/
markdup_fastQC=/home/yuzon/${project}/fastQC/markdup

bin_genome=/home/yuzon/${project}/bbsplit/
bwa_out=/home/yuzon/${project}/aligned/

stampy_realign=/home/yuzon/${project}/aligned/stampy/
flag_out=/home/yuzon/${project}/aligned/stampy/flag/
readgroup_files=/home/yuzon/${project}/aligned/sorted/readgroups/

Sorted=/home/yuzon/${project}/aligned/sorted/
Depth_dir=/home/yuzon/${project}/aligned/sorted/stats/depth/
dups_dir=/home/yuzon/${project}/aligned/sorted/stats/dups/

snps=/home/yuzon/${project}/SNPcalling/

mkdir $refPTT
mkdir $refPTM
mkdir $merged_genome

mkdir $Raw_reads
mkdir $Raw_fastqc
mkdir $trimmed

mkdir $PEoverlap
mkdir $Pear_fastqc
mkdir $assembled
mkdir $unassembled
mkdir $unassembled_fastqc
mkdir $assembled_fastqc

mkdir $markdup
mkdir $markdup

mkdir $bin_genome

mkdir $readgroup_files

mkdir $bwa_out

mkdir $stampy_realign
mkdir $flag_out

mkdir $Sorted
mkdir $Depth_dir

mkdir $snps


#####################################################
echo "Trim adaptors, min quality =30, min length =40"
#####################################################
#cd ${Raw_reads}
#for each in *1.fastq.gz
#do
#echo ${each}
#java -jar ${trimmo}trimmomatic-0.38.jar PE -threads 5 \
#      $each ${each%1.fastq.gz}2.fastq.gz \
#      ${trimmed}${each%1.fastq.gz}P_1.fastq ${trimmed}${each%1.fastq.gz}U_1.fastq \
#      ${trimmed}${each%1.fastq.gz}P_2.fastq ${trimmed}${each%1.fastq.gz}U_2.fastq \
#      ILLUMINACLIP:${trimmo}adapters/TruSeq3-PE-2.fa:2:30:10 \
#      SLIDINGWINDOW:3:28 MINLEN:40
#done

##FastQC

#cd ${trimmed}
#for each in *fastq
#do
#${fastqc} ${each}
#done


####################################################
echo "PEAR: merge overlapping paired reads"#########
####################################################
cd ${trimmed}
###DONT USE REMOVES TOO MUCH DATA
##for each in *P_1.fastq
##do
##${pear} -f  ${each} -j 4 -r ${each%_1.fastq}_2.fastq -n 0 -k -o ${each%_1.fastq}

##${fastqc} ${each%_1.fastq}.assembled.fastq \
##${each%_1.fastq}.unassembled.forward.fastq ${each%_1.fastq}.unassembled.reverse.fastq \
##--outdir ${Pear_fastqc}
##done

##mv *unassembled.fastq ${unassembled}
##mv *assembled.fastq ${assembled}


##########################################################################################################
echo "Merge Singleton Files: Trimmomatic Unpaired (For and Rev) and PEAR (Paired overlap/assembled)"######
##########################################################################################################
#for each in *_U_1.fastq
#do
#cat ${each} \
#${each%_U_1.fastq}_U_2.fastq \
#> ${assembled}${each%_U_1.fastq}.singles.fastq
#done



###########################################################
echo "Prinseq: remove PCR duplicates"######################
###########################################################
###prinseq needs this version of perl but this version interferes with other software

#module load perl/5.26.1

#cd ${assembled}
##singles
#for each in *singles.fastq
#do
#echo ${each}
#perl /data/biosoftware/prinseq/bin/prinseq-lite.pl -fastq ${each} \
#-log -verbose -derep 14 -trim_qual_left 30 -trim_qual_right 30 -trim_qual_window 30 -trim_qual_step 3 \
#-min_len 40 -out_format 3 -out_good ${markdup}${each%.singles.fastq}.markdup
#done

##paired
#cd ${trimmed}

#for each in *_P_1.fastq 
#do 
#echo ${each}
#echo ${each%_P_1}_P_2.fastq 
#perl /data/biosoftware/prinseq/bin/prinseq-lite.pl \
#-fastq ${each} \
#-fastq2 ${each%_P_1.fastq}_P_2.fastq \
#-log -verbose -derep 14 -out_format 3 \
#-out_good ${markdup}${each%_P_1.fastq}.markdup
#done

###prinseq needs this version of perl but this version interferes with other software
#module unload perl/5.26.1 

#for each in *_P_1.fastq
#do
#fastqc ${markdup}${each%_P_1.fastq}.markdup_1.fastq --outdir ${markdup_fastqc}
#fastqc ${markdup}${each%_P_1.fastq}.markdup_2.fastq --outdir ${markdup_fastqc}
#fastqc ${markdup}${each%_P_1.fastq}.markdup.fastq --outdir ${markdup_fastqc}
#done


#################################################################
echo "BBSplit: Bin reads to best matching Parent Genome"#########
#################################################################
cd ${markdup}

for each in *.markdup_1.fastq
do
##paired
$BBMAPDIR/bbsplit.sh minratio=0.52 ambiguous=best ambiguous2=all \
in1=${each} in2=${each%.markdup_1.fastq}.markdup_2.fastq \
ref=$refPTT,$refPTM basename=${bin_genome}${each%.markdup_1.fastq}_P_%.fq
##singles
$BBMAPDIR/bbsplit.sh minratio=0.52 ambiguous=best ambiguous2=all \
in1=${each%.markdup_1.fastq}.markdup.fastq \
ref=$refPTT,$refPTM basename=${bin_genome}${each%.markdup_1.fastq}_%.fq

done


#########################################################
echo "Trimmomatic: Trim reads based on quality"##########
#########################################################
##cd ${bin_genome}
#######don't use before bbsplit because different read numbers in paired file
#######filter similar to first trimmomatic stepu
##for each in *_1..fastq
##do
##echo ${each}
##java -jar /data/biosoftware/Trimmomatic/Trimmomatic-0.38/trimmomatic-0.38.jar \
##PE ${each} ${each%_1.markdup.fastq}_2.markdup.fastq \
##${each%_1.markdup.fastq}.qual.fastq \
##LEADING:30 SLIDINGWINDOW:3:30 MINLEN:40
##${fastqc} ${each%.markdup.fastq}.qual.fastq
##done

##for each in *markdup.fastq
##do
##echo ${each}
##java -jar /data/biosoftware/Trimmomatic/Trimmomatic-0.38/trimmomatic-0.38.jar \
##SE ${each} ${each%.markdup.fastq}.qual.fastq LEADING:30 SLIDINGWINDOW:3:30 MINLEN:40
##${fastqc} ${each%.markdup.fastq}.qual.fastq
##done


##########################################################
echo "BWA: Alignment"#####################################
##########################################################
cd ${bin_genome}

${bwa_soft}bwa index ${refPTT}
${bwa_soft}bwa index ${refPTM}

#####map to PTT
for each in *_P_PTT_0-1_assembly.v14.fq
do
#${bwa_soft}bwa mem -M -t 4 -p ${refPTT} ${each} \
#> ${bwa_out}${each%_P_PTT_0-1_assembly.v14.fq}.PTT.PE.sam

${bwa_soft}bwa mem -M -t 4 ${refPTT} \
${each%_P_PTT_0-1_assembly.v14.fq}_PTT_0-1_assembly.v14.fq \
> ${bwa_out}${each%_P_PTT_0-1_assembly.v14.fq}.PTT.SE.sam
done


#####map to PTM
for each in *_P_PTM_FGOB10Ptm-1_assembly.v7.fq
do
#${bwa_soft}bwa mem -M -t 4 -p ${refPTM} ${each} \
#> ${bwa_out}${each%_P_PTM_FGOB10Ptm-1_assembly.v7.fq}.PTM.PE.sam

${bwa_soft}bwa mem -M -t 4 ${refPTM} \
${each%_P_PTM_FGOB10Ptm-1_assembly.v7.fq}_PTM_FGOB10Ptm-1_assembly.v7.fq \
> ${bwa_out}${each%_P_PTM_FGOB10Ptm-1_assembly.v7.fq}.PTM.SE.sam

###concatenate PTT and PTM bam files
cat ${bwa_out}${each%_P_1.PTM_FGOB10Ptm-1_assembly.v7.fq}.PTT.PE.sam  ${bwa_out}${each%_P_1.PTM_FGOB10Ptm-1_assembly.v7.fq}.PTM.PE.sam
cat ${bwa_out}${each%_P_1.PTM_FGOB10Ptm-1_assembly.v7.fq}.PTT.SE.sam  ${bwa_out}${each%_P_1.PTM_FGOB10Ptm-1_assembly.v7.fq}.PTM.SE.sam
done


##########################################################
echo "Stampy: Indel Realigner/Assess Insert Size"#########
##########################################################
module load python/2.7.13

cd ${bwa_output}


####make BAM
for each in *.sam
do
${samtools_soft}samtools view -S -b ${each} > ${each%.sam}.bam  
done

####stampy

${stampy_soft}stampy.py -G ptg ${Ref}

${stampy_soft}stampy.py -g ptg -H ptg

for each in *.bam
do
echo ${each}
${stampy_soft}stampy.py -g ptg -h ptg -t4 --bamkeepgoodreads -M ${each} -o ${out_dir}${each%.bam}.stampy.sam
done

cd ${out_dir}
for each in *.sam
do
echo ${each}
${samtools_soft}samtools flagstat ${each} > ${flag_out}${each}.stats
done

unload module

##########################################################
echo "Samtools: Sort"#####################################
##########################################################
cd ${aligned_dir}
for each in *.stampy.sam
do
echo ${each}
samtools sort -o ${Sorted}${each%.stampy.sam}.sorted.bam -@ 4 ${each}
samtools depth -a ${Sorted}${each%.stampy.sam}.sorted.bam > ${Depth_dir}${each}.stats
done

##########################################################
echo "Samtools: Merge"####################################
##########################################################
cd ${Sorted}

for each in *.PE.sorted.bam
do
echo ${each}
samtools merge ${each%.PE.sorted.bam}.merged.bam \
${each} ${each%.PE.sorted.bam}.SE.sorted.bam
done

##########################################################
echo "Picard: ReadGroup"##################################
##########################################################
for each in *.merged.bam
do
echo ${each}
var=`samtools view ${each} | head -n 1 | cut -f1 | cut -d ":" -f 3,4`
java -jar /data/biosoftware/Picard/Picard/picard.jar AddOrReplaceReadGroups \
       I=${each} \
       O=${each%.merged.bam}.read.bam \
       RGID="$var"\
       RGLB=lb1\
       RGPL=illumina \
       RGPU=unit1 \
       RGSM=${each%.merged.bam}
done

##########################################################
echo "GATK: Haplotype Caller"#############################
##########################################################
#for each in *.read.bam
#do

#samtools index $each
#gatk --java-options "-Xmx4g" HaplotypeCaller \
#   -R ${merged_genome} \
#   -I ${each} \
#   -ERC BP_RESOLUTION \
#   -ploidy 1 \
#   -O ${snps}${each%.read.bam}.vcf.gz

#done

##########################################################
echo "GATK: CombineGVCFs"#################################
##########################################################
cd $snps
#gatk CombineGVCFs \
#   -R ${merged_genome} \
#--variant 10_P.vcf.gz \
#--variant 20_P.vcf.gz \
#--variant 30_P.vcf.gz \
#--variant 40_P.vcf.gz \
#--variant 50_P.vcf.gz \
#--variant 60_P.vcf.gz \
#--variant 70_P.vcf.gz \
#--variant 79_P.vcf.gz \
#--variant 79b_P.vcf.gz \
#--variant 90_P.vcf.gz \
#--variant 100_P.vcf.gz \
#-O cohort2.g.vcf.gz

##########################################################
echo "GATK: Call Genotypes"###############################
##########################################################

#java -jar /data/biosoftware/GATK/GATK/GenomeAnalysisTK.jar \
#   -T GenotypeGVCFs \
#   -R $reference \
#--variant cohort2.g.vcf.gz \
#-o Genotype.vcf

##########################################################
echo "GATK: Hardfiltering"################################
##########################################################
#gatk VariantFiltration \
#   -R $reference \
#   -V Genotype.vcf \
#   -O FilteredNew.vcf \
#   --filter-expression "QD < 2.0 || DP < 8.0 || MQ < 40.0 || MQRankSum < -12.5 || ReadPosRankSum < -8.0" \
#   --filter-name "INFO" \
#   --genotype-filter-expression "DP < 2" \
#   --genotype-filter-name "LowDepth"

##########################################################
echo "GATK: Remove loci based on missing info"############
##########################################################
#gatk SelectVariants \
#-V FilteredNew.vcf \
#--set-filtered-gt-to-nocall \
#-O FilteredNewNoCall.vcf

##vcftools --remove names.txt --vcf FilteredNewNoCall.vcf --out FilteredRM --recode --recode-INFO-all

##vcftools --max-missing 0.5 --vcf FilteredRM.recode.vcf --out FullyFiltered --recode --recode-INFO-all
##vcftools --max-missing 0.5 --vcf FilteredNewNoCall.vcf --out FullyFiltered --recode --recode-INFO-all
vcftools --max-missing 0.9 --vcf FilteredNewNoCall.vcf --out FullyFiltered --recode --recode-INFO-all

#gatk SelectVariants \
 #    -R $reference \
  #   -V FullyFiltered.recode.vcf \
   #  --exclude-filtered -O ExcludeFilters.vcf

#gatk SelectVariants \
 #    -R $reference \
  #   -V ExcludeFilters.vcf \
   #  --exclude-non-variants -O VariantOnly.vcf

##########################################################
echo "VCFtools: Missing INFO"#############################
##########################################################

#vcftools --missing-indv --vcf Genotype.vcf --out missRAW
#vcftools --missing-indv --vcf FilteredNewNoCall.vcf --out missHF
#vcftools --missing-indv --vcf FilteredRM.recode.vcf --out misssampleRem
#vcftools --missing-indv --vcf FullyFiltered.recode.vcf misspossRem
#vcftools --missing-indv --vcf ExcludeFilters.vcf --out missFlagout
#vcftools --missing-indv --vcf VariantOnly.vcf --out missVaronly

