#!/bin/bash
#
#  submit by  sbatch trim.sh
#
#  specify the job name
#SBATCH --job-name=trim
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=10:00:00
#  maximum requested memory
#SBATCH --mem=10G
#  write std out and std error to these files
#SBATCH --error=trim.%J.err
#SBATCH --output=trim.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#  add your code here:


#cd /home/taliadoros/trimmo/trimmed/pear/unassembled/prinseq
#for each in *1.fastq
#do
#echo ${each}
#java -jar /data/biosoftware/Trimmomatic/Trimmomatic-0.38/trimmomatic-0.38.jar PE -threads 5 ${each} ${each%1.fastq}2.fastq ${each%1.fastq}P_1.fastq ${each%1.fastq}U_1.fastq ${each%1.fastq}P_2.fastq ${each%1.fastq}U_2.fastq LEADING:30 SLIDINGWINDOW:3:30 MINLEN:40

#/data/biosoftware/FastQC/FastQC/fastqc ${each%1.fastq}P_1.fastq ${each%1.fastq}U_1.fastq ${each%1.fastq}P_2.fastq ${each%1.fastq}U_2.fastq 
#done

cd /mnt/beegfs/yuzon/trimmed/prinseq

for each in *.fastq
do
echo ${each}
java -jar /data/biosoftware/Trimmomatic/Trimmomatic-0.38/trimmomatic-0.38.jar SE ${each} ${each}qual.fastq LEADING:30 SLIDINGWINDOW:3:30 MINLEN:40
/data/biosoftware/FastQC/FastQC/fastqc ${each}qual.fastq
done
