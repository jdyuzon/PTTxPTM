#!/bin/bash
#Extract %GC from fastqc files

fastqc_dir=/home/taliadoros/Desktop/fastqc/prinseq_assembled/
table_file=GC_content.txt
fastqc_dir2=/home/taliadoros/Desktop/fastqc/final_trim_unassembled/
table_file2=GC_content.txt
fastqc_dir3=/home/taliadoros/Desktop/fastqc/prinseq_unassembled/
table_file3=GC_content.txt
fastqc_dir4=/home/taliadoros/Desktop/fastqc/final_trim_assembled/
table_file4=GC_content.txt
fastqc_dir5=/home/taliadoros/Desktop/folder/trimmo/trimmed/fastQC_reports1/
table_file5=GC_content.txt
fastqc_dir6=/home/taliadoros/Desktop/folder/trimmo/trimmed/pear/fastqc_pear/
table_file6=GC_content.txt

#cd ${fastqc_dir}
#for folder in *_fastqc
#do
#echo ${folder}
#grep '.fastq' ${fastqc_dir}${folder}/fastqc_data.txt | cut -f 2 -d '	' |tr '\n' '\t' >> ${table_file}
#cat ${fastqc_dir}${folder}/fastqc_data.txt | head -n 10 | tail -n 1 | cut -f 1 -d '' >> ${table_file}
#done

 
#cd ${fastqc_dir2}
#for folder in *_fastqc
#do
#echo ${folder}
#grep '.fastq' ${fastqc_dir2}${folder}/fastqc_data.txt | cut -f 2 -d '	' |tr '\n' '\t' >> ${table_file2}
#cat ${fastqc_dir2}${folder}/fastqc_data.txt | head -n 10 | tail -n 1 | cut -f 1 -d '' >> ${table_file2}
#done

#cd ${fastqc_dir3}
#for folder in *_fastqc
#do
#echo ${folder}
#grep '.fastq' ${fastqc_dir3}${folder}/fastqc_data.txt | cut -f 2 -d '	' |tr '\n' '\t' >> ${table_file3}
#cat ${fastqc_dir3}${folder}/fastqc_data.txt | head -n 10 | tail -n 1 | cut -f 1 -d '' >> ${table_file3}
#done

#cd ${fastqc_dir4}
#for folder in *_fastqc
#do
#echo ${folder}
#grep '.fastq' ${fastqc_dir4}${folder}/fastqc_data.txt | cut -f 2 -d '	' |tr '\n' '\t' >> ${table_file4}
#cat ${fastqc_dir4}${folder}/fastqc_data.txt | head -n 10 | tail -n 1 | cut -f 1 -d '' >> ${table_file4}
#done

cd ${fastqc_dir5}
for folder in *_fastqc
do
echo ${folder}
grep '.fq.gz' ${fastqc_dir5}${folder}/fastqc_data.txt | cut -f 2 -d '	' |tr '\n' '\t' >> ${table_file5}
cat ${fastqc_dir5}${folder}/fastqc_data.txt | head -n 10 | tail -n 1 | cut -f 1 -d '' >> ${table_file5}
done

#cd ${fastqc_dir6}
#for folder in *_fastqc
#do
#echo ${folder}
#grep '.fastq' ${fastqc_dir6}${folder}/fastqc_data.txt | cut -f 2 -d '	' |tr '\n' '\t' >> ${table_file6}
#cat ${fastqc_dir6}${folder}/fastqc_data.txt | head -n 10 | tail -n 1 | cut -f 1 -d '' >> ${table_file6}
#done

