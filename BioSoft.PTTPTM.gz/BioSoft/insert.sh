#!/bin/bash
#
#  submit by  sbatch insert.sh
#
#  specify the job name
#SBATCH --job-name=insert_size
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=30:00:00
#  maximum requested memory
#SBATCH --mem=10G
#  write std out and std error to these files
#SBATCH --error=insert.%J.err
#SBATCH --output=insert.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#  add your code here:

input_dir=/mnt/beegfs/yuzon/aligned/sorted/
picard_soft=/data/biosoftware/Picard/Picard/

cd ${input_dir}

for each in *.bam
do

#java -jar ${picard_soft}picard.jar CollectInsertSizeMetrics \
 #     I=${each} \
  #    O=${each%.bam}.insert_size_metrics.txt \
   #   H=${each%bam}insert_size_histogram.pdf \
    #  M=0.5

samtools stats $each > ${each%.bam}.samtools.stats.txt

done
