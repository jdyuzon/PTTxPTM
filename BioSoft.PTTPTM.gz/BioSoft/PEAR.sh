#!/bin/bash
#
#  submit by  sbatch PEAR.sh
#
#  specify the job name
#SBATCH --job-name=PEAR
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=10:00:00
#  maximum requested memory
#SBATCH --mem=10G
#  write std out and std error to these files
#SBATCH --error=job.%J.err
#SBATCH --output=job.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#  add your code here:

trimmed=/home/taliadoros/trimmo/trimmed
fastqc_outdir=/home/taliadoros/trimmo/trimmed/pear/fastqc_pear
assembled=/home/taliadoros/trimmo2/trimmed/pear/assembled/
unassembled=/home/taliadoros/trimmo/trimmed/pear/unassembled/
pear=/home/taliadoros/software/pear-0.9.11-linux-x86_64/bin/
fastqc=/home/taliadoros/software/FastQC/fastqc

mkdir /home/taliadoros/trimmo/trimmed/pear
mkdir /home/taliadoros/trimmo/trimmed/pear/assembled
mkdir /home/taliadoros/trimmo/trimmed/pear/unassembled
mkdir ${fastqc_outdir}

cd ${trimmed}

for each in *1.fq.gz
do
${pear}pear -f  ${each} -j 4 -r ${each%1.fq.gz}2.fq.gz -n 0 -k -o ${each%1.fq.gz}

${fastqc} ${each%1.fq.gz}.assembled.fastq ${each%1.fq.gz}.unassembled.forward.fastq ${each%1.fq.gz}.unassembled.reverse.fastq --outdir ${fastqc_outdir}
done

mv *assembled.fastq ${assembled}
mv *unassembled* ${unassembled}
