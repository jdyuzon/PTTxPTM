#!/bin/bash
#
#  submit by  sbatch merge.sh
#
#  specify the job name
#SBATCH --job-name=samtools
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=20:00:00
#  maximum requested memory
#SBATCH --mem=10G
#  write std out and std error to these files
#SBATCH --error=sam.%J.err
#SBATCH --output=sam.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#  add your code here:
cd /mnt/beegfs/yuzon/aligned/sorted/
for each in *bam
do
echo ${each}
var=`samtools view ${each} | head -n 1 | cut -f1 | cut -d ":" -f 3,4`
java -jar /data/biosoftware/Picard/Picard/picard.jar AddOrReplaceReadGroups \
       I=${each} \
       O=${each%bam}read.bam \
       RGID="$var"\
       RGLB=lb1\
       RGPL=illumina \
       RGPU=unit1 \
       RGSM=${each}
done

