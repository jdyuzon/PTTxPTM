#!/bin/bash
#
#  submit by  sbatch Haplotype_caller.sh
#
#  specify the job name
#SBATCH --job-name=t
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=90:00:00
#  maximum requested memory
#SBATCH --mem=15G
#  write std out and std error to these files
#SBATCH --error=t.%J.err
#SBATCH --output=t.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

###########################################################
echo "Software"
###########################################################
##module load java/x64/8u121

harvest=/data/biosoftware/harvest/harvest


##########################################################
echo "Directories"
##########################################################


##########################################################
#${harvest}/parsnp -r /home/yuzon/references/parsnp_ref/test.fa -d  /home/yuzon/references/parsnp_ref/parsnp_qry 
${harvest}/harvesttools -i /home/yuzon/PTTxPTMtest/P_2020_03_02_142634495199/parsnp.ggr -V /home/yuzon/PTTxPTMtest/P_2020_03_02_142634495199/parsnp.vcf
