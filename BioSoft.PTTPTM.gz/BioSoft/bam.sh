#!/bin/bash
#
#  submit by  sbatch samtools.sh
#
#  specify the job name
#SBATCH --job-name=samtools
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=10:00:00
#  maximum requested memory
#SBATCH --mem=10G
#  write std out and std error to these files
#SBATCH --error=samtools.%J.err
#SBATCH --output=samtools.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

mkdir /home/taliadoros/bwa/bam
cd /home/taliadoros/bwa/
for each in *.sam
do
echo ${each}
samtools view -S -b ${each} > /home/taliadoros/bwa/bam/${each%.sam}.bam
done
