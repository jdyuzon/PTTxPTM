#!/bin/bash

#
#  submit by  sbatch Haplotype_caller.sh
#
#  specify the job name
#SBATCH --job-name=PTTxPTMrecomb
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=90:00:00
#  maximum requested memory
#SBATCH --mem=70G
#  write std out and std error to these files
#SBATCH --error=PTTxPTMrecomb.%J.err
#SBATCH --output=PTTxPTMrecomb.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#################################################################################################################
############################Create a r2 and r matrix#############################################################
#################################### Plink ######################################################################
#grep "##" ../32.PTMPTT.flt.vcf >header
#awk -v OFS="\t" '{print $1,$2,$1":"$2"-"$3,"T","A",".",".",".","GT:AD:DP:GQ:PL"}' all.recomblocks.bed >ptt.columns
#sed 's/PTT_/ptt_/g' ptt.columns| sed 's/0-1_contig/ptm/g'|tail -n +2 >ptm.columns
#cat ptt.columns ptm.columns \
#|sed  "1s/.*/#CHROM POS ID	 REF ALT QUAL FILTER INFO FORMAT/" \
#|awk '{$1=$1}1' OFS="\t" >columns
#sed 's/PTT/0\/0/g' all.recomblocks.vcf.tmp |sed 's/PTM/0\/1/g' | sed 's/\./\.\/\./g'|paste columns - | cat header - >all.recomblocks.ptm.vcf
#sed 's/PTT/0\/1/g' all.recomblocks.vcf.tmp |sed 's/PTM/0\/0/g' | sed 's/\./\.\/\./g'|paste columns - | cat header - >all.recomblocks.ptt.vcf

#vcftools --vcf all.recomblocks.ptm.vcf --max-missing-count 100 --out all.recomblocks.ptm --recode
#vcftools --vcf all.recomblocks.ptt.vcf --max-missing-count 100 --out all.recomblocks.ptt --recode
#####check if error such that PTT and PTM alles in an isolate overlap
#grep 'chrPTT_.*chrPTT_.*PTM.*chrPTT_.*PTT' *.ranges.bed
#grep 'contig.*contig.*PTM.*contig.*PTT' *.ranges.bed

#Create a r2 and r matrix
##Plink
#/data/biosoftware/plink/v1.90beta4/plink --r square --vcf all.recomblocks.ptm.recode.vcf --recode structure --out all.r.ptm.matrix --allow-extra-chr
#/data/biosoftware/plink/v1.90beta4/plink --r2 square --vcf all.recomblocks.ptm.recode.vcf --recode structure --out all.r2.ptm.matrix --allow-extra-chr

#/data/biosoftware/plink/v1.90beta4/plink --r square --vcf all.recomblocks.ptt.recode.vcf --recode structure --out all.r.ptt.matrix --allow-extra-chr
#/data/biosoftware/plink/v1.90beta4/plink --r2 square --vcf all.recomblocks.ptt.recode.vcf --recode structure --out all.r2.ptt.matrix --allow-extra-chr

#/data/biosoftware/plink/v1.90beta4/plink --r2 inter-chr --vcf all.recomblocks.ptm.recode.vcf --recode structure --out all.r2.ptm --allow-extra-chr
#/data/biosoftware/plink/v1.90beta4/plink --r inter-chr --vcf all.recomblocks.ptm.recode.vcf --recode structure --out all.r.ptm --allow-extra-chr

#/data/biosoftware/plink/v1.90beta4/plink --r2 inter-chr --vcf all.recomblocks.ptt.recode.vcf --recode structure --out all.r2.ptt --allow-extra-chr
#/data/biosoftware/plink/v1.90beta4/plink --r inter-chr --vcf all.recomblocks.ptt.recode.vcf --recode structure --out all.r.ptt --allow-extra-chr

#awk '$1!=$4  {print $0}' all.r.ptm.ld >all.r.ptm.inter.ld
#awk '$1!=$4  {print $0}' all.r2.ptm.ld >all.r2.ptm.inter.ld

#awk '$1!=$4  {print $0}' all.r.ptt.ld >all.r.ptt.inter.ld
#awk '$1!=$4  {print $0}' all.r2.ptt.ld >all.r2.ptt.inter.ld

#module load R
#Rscript --vanilla LinkageDisequilibrium.R all.r.ptm.matrix.ld all.r2.ptm.matrix.ld all.r2.ptm.ld all.r.ptm.inter.ld
#Rscript --vanilla LinkageDisequilibrium.R all.r.ptt.matrix.ld all.r2.ptt.matrix.ld all.r2.ptt.ld all.r.ptt.inter.ld

####### Get Parental and Hybrid Frequencies
#vcftools --vcf all.recomblocks.ptm.recode.vcf --out all.recomblocks.ptm.recode --plink

#while read p 
#do
#  pairs=`echo "$p"| grep -v "SNP"|awk '{print $3 "\t" $6}'` 
#  /data/biosoftware/plink/v1.07/plink-1.07-x86_64/plink --ld $pairs --file all.recomblocks.ptm.recode --noweb \
#  |grep "AA\|TT\|AT\|TA\|A0\|T0\|0A\|0T" |awk '{print $2}' |grep -v "In\|LD\|ld\|info\|phase"| awk 'BEGIN { ORS = " " } { print }'
#  echo "$pairs"
#done <all.r.ptm.ld >all.pairs.freq

#/data/biosoftware/plink/v1.90beta4/plink --ld chrPTT_1:129482-129524 chrPTT_1:129524-131079 --vcf all.recomblocks.ptt.recode.vcf --recode structure --out test --allow-extra-chr 
#/data/biosoftware/plink/v1.90beta4/plink --ld chrPTT_1:129482-129524 0-1_contig_m86:100244-101644 --vcf all.recomblocks.ptt.recode.vcf --recode structure --out test2 --allow-extra-chr


###################################### Test Parallelization of Parental and Hybrid Frequencies f(x)
#mkdir splitfiles
cd splitfiles
#cp ../all.r.ptm.ld .
#cp ../all.recomblocks.ptm.recode* .

#split -l 100000 -d all.r.ptm.ld all.r.ptm.ld-

for file in all.r.ptm.ld-*
do

sbatch ../SL_recombination.sh $file

done



