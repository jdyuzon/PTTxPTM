#!/bin/bash
#
#  submit by  sbatch missingdata.sh
#
#  specify the job name
#SBATCH --job-name=GATK
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=90:00:00
#  maximum requested memory
#SBATCH --mem=15G
#  write std out and std error to these files
#SBATCH --error=vcf.%J.err
#SBATCH --output=vcf.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#  add your code here:

cd /home/taliadoros/bwa/stampy/sorted/merged/merged/RGed/index/haplotype_caller/

gatk SelectVariants \
-V FilteredNew.vcf \
--set-filtered-gt-to-nocall \
-O FilteredNewNoCall.vcf

cd /home/taliadoros/bwa/stampy/sorted/merged/merged/RGed/index/haplotype_caller/
vcftools --remove /home/taliadoros/bwa/stampy/sorted/merged/merged/RGed/index/haplotype_caller/names.txt --vcf FilteredNewNoCall.vcf --out FilteredRM --recode --recode-INFO-all

cd /home/taliadoros/bwa/stampy/sorted/merged/merged/RGed/index/haplotype_caller/
vcftools --max-missing 0.5 --vcf FilteredRM.recode.vcf --out FullyFiltered --recode --recode-INFO-all

cd /home/taliadoros/bwa/stampy/sorted/merged/merged/RGed/index/haplotype_caller/
reff=/home/taliadoros/Reff_gen/0-1_assembly.v14.fa

     gatk SelectVariants \
     -R $reff \
     -V FullyFiltered.recode.vcf \
     --exclude-filtered -O ExcludeFilters.vcf

cd /home/taliadoros/bwa/stampy/sorted/merged/merged/RGed/index/haplotype_caller/
reff=/home/taliadoros/Reff_gen/0-1_assembly.v14.fa     
gatk SelectVariants \
     -R $reff \
     -V ExcludeFilters.vcf \
     --exclude-non-variants -O VariantOnly.vcf
