#!/bin/bash
#
#  submit by  sbatch Haplotype_caller.sh
#
#  specify the job name
#SBATCH --job-name=PTTxPTMhybrid
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=90:00:00
#  maximum requested memory
#SBATCH --mem=15G
#  write std out and std error to these files
#SBATCH --error=PTTxPTMhybrid.%J.err
#SBATCH --output=PTTxPTMhybrid.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

###########################################################
echo "Software"
###########################################################
##module load java/x64/8u121

trimmo=/data/biosoftware/Trimmomatic/Trimmomatic-0.38/
pear=/data/biosoftware/pear/pear-0.9.10-bin-64/pear-0.9.10-bin-64 
export BBMAPDIR=/data/biosoftware/bbmap/bbmap
bwa_soft=/data/biosoftware/bwa/bwa-0.7.15/
stampy_soft=/data/biosoftware/stampy/stampy/
samtools_soft=/data/biosoftware/samtools/samtools-1.9/
fastqc=/data/biosoftware/FastQC/FastQC/fastqc


##########################################################
echo "Directories"
##########################################################

refPTT=/home/yuzon/references/hybrid_references/PTT_0-1_assembly.v14.fa
refPTM=/home/yuzon/references/hybrid_references/PTM_FGOB10Ptm-1_assembly.v7.fasta
merged_genome=/home/yuzon/references/hybrid_references/merged_genome_PTTxPTM.fasta

Raw_reads=/home/yuzon/raw_reads/
Raw_fastqc=/home/yuzon/PTTxPTMtest/fastQC/raw_fastqc
trimmed=/home/yuzon/PTTxPTMtest/trimmed/

PEoverlap=/home/yuzon/PTTxPTMtest/trimmed/pear/
Pear_fastqc=/home/yuzon/PTTxPTMtest/fastQC/fastqc_pear
assembled=/home/yuzon/PTTxPTMtest/trimmed/pear/assembled/
unassembled=/home/yuzon/PTTxPTMtest/trimmed/pear/unassembled/
unassembled_fastqc=/home/yuzon/PTTxPTMtest/fastQC/fastqc_unassembled
assembled_fastqc=/home/yuzon/PTTxPTMtest/fastQC/fastqc_assembled

markdup=/home/yuzon/PTTxPTMtest/trimmed/prinseq/
markdup_fastQC=/home/yuzon/PTTxPTMtest/fastQC/markdup

bin_genome=/home/yuzon/PTTxPTMtest/bbsplit/

readgroup_files=/home/yuzon/PTTxPTMtest/aligned/sorted/readgroups/

bwa_input=/home/yuzon/PTTxPTMtest/aligned/
bwa_out=/home/yuzon/PTTxPTMtest/aligned/

stampy_realign=/home/yuzon/PTTxPTMtest/aligned/stampy/
flag_out=/home/yuzon/PTTxPTMtest/aligned/stampy/flag/

Sorted=/home/yuzon/PTTxPTMtest/aligned/sorted/
Depth_dir=/home/yuzon/PTTxPTMtest/aligned/sorted/stats/depth/
dups_dir=/home/yuzon/PTTxPTMtest/aligned/sorted/stats/dups/



mkdir $refPTT
mkdir $refPTM
mkdir $merged_genome

mkdir $Raw_reads
mkdir $Raw_fastqc
mkdir $trimmed

mkdir $PEoverlap
mkdir $Pear_fastqc
mkdir $assembled
mkdir $unassembled
mkdir $unassembled_fastqc
mkdir $assembled_fastqc

mkdir $markdup
mkdir $markdup

mkdir $bin_genome

mkdir $readgroup_files

mkdir $bwa_input
mkdir $bwa_out

mkdir $stampy_realign
mkdir $flag_out

mkdir $Sorted
mkdir $Depth_dir


#####################################################
echo "Trim adaptors, min quality =29, min length =40"
#####################################################
cd ${Raw_reads}
#for each in *1.fq.gz
#do
#echo ${each}
#java -jar ${trimmo}trimmomatic-0.38.jar PE -threads 5 \
 #                               $each ${each%1.fq.gz}2.fq.gz \
  #                              ${trimmed}${each%1.fq.gz}P_1.fastq ${trimmed}${each%1.fq.gz}U_1.fastq \
   #                             ${trimmed}${each%1.fq.gz}P_2.fastq ${trimmed}${each%1.fq.gz}U_2.fastq \
    #                            ILLUMINACLIP:${trimmo}adapters/TruSeq3-PE-2.fa:2:30:10 SLIDINGWINDOW:3:28 MINLEN:40
#done


#FastQC

#cd ${trimmed}
#for each in *fastq
#do
#${fastqc} ${each}
#done


####################################################
echo "PEAR: merge overlapping paired reads"#########
####################################################
cd ${trimmed}

#for each in *P_1.fastq
#do
#${pear} -f  ${each} -j 4 -r ${each%_1.fastq}_2.fastq -n 0 -k -o ${each%_1.fastq}

#${fastqc} ${each%_1.fastq}.assembled.fastq \
#${each%_1.fastq}.unassembled.forward.fastq ${each%_1.fastq}.unassembled.reverse.fastq \
#--outdir ${Pear_fastqc}
#done

#mv *unassembled.fastq ${unassembled}
#mv *assembled.fastq ${assembled}


##########################################################################################################
echo "Merge Singleton Files: Trimmomatic Unpaired (For and Rev) and PEAR (Paired overlap/assembled)"######
##########################################################################################################

cd ${assembled} 

#for each in *_P.assembled.fastq
#do
#cat ${each} \
#${trimmed}${each%_P.assembled.fastq}_U_1.fastq \
#${trimmed}${each%_P.assembled.fastq}_U_2.fastq \
#> ${assembled}${each%_P.assembled.fastq}.singles.fastq

#done



###########################################################
echo "Prinseq: remove PCR duplicates"######################
###########################################################
###prinseq needs this version of perl but this version interferes with other software

module load perl/5.26.1

##singles
for each in *singles.fastq
do
echo ${each}
perl /data/biosoftware/prinseq/bin/prinseq-lite.pl -fastq ${each} \
-log -verbose -derep 14 -trim_qual_left 30 -trim_qual_right 30 -trim_qual_window 30 -trim_qual_step 3 \
-min_len 40 -out_format 3 -out_good ${markdup}${each%.singles.fastq}.markdup
done

##paired
cd ${unassembled}
for each in *forward.fastq 
do 
echo ${each}
echo ${each%.forward.fastq}.reverse.fastq 
perl /data/biosoftware/prinseq/bin/prinseq-lite.pl \
-fastq ${each} \
-fastq2 ${each%.forward.fastq}.reverse.fastq \
-log -verbose -derep 14 -out_format 3 \
-out_good ${markdup}${each%.unassembled.forward.fastq}

mv ${markdup}${each%.unassembled.forward.fastq}_1.fastq ${markdup}${each%.unassembled.forward.fastq}_1.markdup.fastq
mv ${markdup}${each%.unassembled.forward.fastq}_2.fastq ${markdup}${each%.unassembled.forward.fastq}_2.markdup.fastq 
fastqc ${markdup}*fastq --outdir ${markdup_fastqc}
done

###prinseq needs this version of perl but this version interferes with other software
module unload perl/5.26.1 

#########################################################
echo "Trimmomatic: Trim reads based on quality"##########
#########################################################
cd ${markdup}

for each in *.fastq
do
echo ${each}
java -jar /data/biosoftware/Trimmomatic/Trimmomatic-0.38/trimmomatic-0.38.jar \
SE ${each} ${each}qual.fastq LEADING:30 SLIDINGWINDOW:3:30 MINLEN:40
${fastqc} ${each%.markdup.fastq}.qual.fastq
done


#################################################################
echo "BBSplit: Bin reads to best matching Parent Genome"#########
#################################################################

for each in *qual.fastq
do

$BBMAPDIR/bbsplit.sh minratio=0.52 ambiguous=best ambiguous2=all\
in1=${each} in2=${each%1.fastq}2.fastq \
ref=$refPTT,$refPTM basename=${bin_genome}${each%1.fastq}_%.fq

done

##########################################################
echo "BWA: Alignment"#####################################
##########################################################
cd ${bin_genome}

${bwa_soft}bwa index ${refPTT}
${bwa_soft}bwa index ${refPTM}

#####map to PTT
#for each in PTT*_1.fq
#do
#${bwa_soft}bwa mem -M -t 4 ${refPTT} \
#${each} ${each%_1.fq}_2.fq
#> ${bwa_out}${each%_1.fq}.sam
#done

#####map to PTM
#for each in PTM*_1.fastqqual.fq
#do
#${bwa_soft}bwa mem -M -t 4 ${refPTM} \
#${each} ${each%_1.fq}_2.fq
#> ${bwa_out}${each%_1.fq}.sam
###concatenate PTT and PTM bam files
cat ${bwa_out}${each#%_1.fq}.sam  ${bwa_out}${each%_1.fq}.sam
#done



##########################################################
echo "Stampy: Indel Realigner/Assess Insert Size"#########
##########################################################
#module load python/2.7.13

#cd ${bwa_input}


####make BAM
#for each in ${bwa_input}*.sam
#do
#${samtools_soft}samtools view -S -b ${each} > ${each%.sam}.bam  
#done

#stampy

#${stampy_soft}stampy.py -G ptg ${Ref}

#${stampy_soft}stampy.py -g ptg -H ptg

#for each in *P_.bam
#do
#echo ${each}
#${stampy_soft}stampy.py -g ptg -h ptg -t4 --bamkeepgoodreads -M ${each} -o ${out_dir}${each%.bam}.stampy.sam
#done

#cd ${out_dir}
#for each in *.sam
#do
#echo ${each}
#${samtools_soft}samtools flagstat ${each} > ${flag_out}${each}.stats
#done

#unload module

##########################################################
echo "Samtools: Sort"#####################################
##########################################################
#cd ${aligned_dir}
#for each in *.sam
#do
#echo ${each}
#samtools sort -o ${Sorted}${each%.sam}.sorted.bam -@ 4 ${each}
#samtools depth -a ${Sorted}${each%.sam}.sorted.bam > ${Depth_dir}${each}.stats
#done

##########################################################
echo "Samtools: Merge"####################################
##########################################################
#cd ${sorted_dir}
#mkdir merged
#for each in *.sorted.bam
#do
#echo ${each}
#samtools merge ${sorted_dir}merged/${each%.sorted.bam}merged.bam ${each} ${each%.sorted.bam}unassembled.U_1.sorted.bam ${each%sorted.bam}unassembled.U_2.sorted.bam
#done

##########################################################
echo "Picard: ReadGroup"##################################
##########################################################
#cd /mnt/beegfs/yuzon/aligned/sorted/
#for each in *bam
#do
#echo ${each}
#var=`samtools view ${each} | head -n 1 | cut -f1 | cut -d ":" -f 3,4`
#java -jar /data/biosoftware/Picard/Picard/picard.jar AddOrReplaceReadGroups \
#       I=${each} \
#       O=${each%bam}read.bam \
#       RGID="$var"\
#       RGLB=lb1\
#       RGPL=illumina \
#       RGPU=unit1 \
#       RGSM=${each}
#done

##########################################################
echo "GATK: Haplotype Caller"#############################
##########################################################
#cd ${Input_files}

#for each in *.read.bam
#do

#samtools index $each
#gatk --java-options "-Xmx4g" HaplotypeCaller \
#   -R $reference \
#   -I ${each} \
#   -ERC BP_RESOLUTION \
#   -ploidy 1 \
#   -O ${each%_.sorted.read.bam}.vcf.gz

#done

##########################################################
echo "GATK: CombineGVCFs"#################################
##########################################################
#gatk CombineGVCFs \
#   -R $reference \
#--variant 10_P.vcf.gz \
#--variant 20_P.vcf.gz \
#--variant 30_P.vcf.gz \
#--variant 40_P.vcf.gz \
#--variant 50_P.vcf.gz \
#--variant 60_P.vcf.gz \
#--variant 70_P.vcf.gz \
#--variant 79_P.vcf.gz \
#--variant 79b_P.vcf.gz \
#--variant 90_P.vcf.gz \
#--variant 100_P.vcf.gz \
#-O cohort2.g.vcf.gz

##########################################################
echo "GATK: Call Genotypes"###############################
##########################################################

#java -jar /data/biosoftware/GATK/GATK/GenomeAnalysisTK.jar \
#   -T GenotypeGVCFs \
#   -R $reference \
#--variant cohort2.g.vcf.gz \
#-o Genotype.vcf

##########################################################
echo "GATK: Hardfiltering"################################
##########################################################
#gatk VariantFiltration \
#   -R $reference \
#   -V Genotype.vcf \
#   -O FilteredNew.vcf \
#   --filter-expression "QD < 2.0 || DP < 8.0 || MQ < 40.0 || MQRankSum < -12.5 || ReadPosRankSum < -8.0" \
#   --filter-name "INFO" \
#   --genotype-filter-expression "DP < 2" \
#   --genotype-filter-name "LowDepth"

##########################################################
echo "GATK: Remove loci based on missing info"############
##########################################################
#gatk SelectVariants \
#-V FilteredNew.vcf \
#--set-filtered-gt-to-nocall \
#-O FilteredNewNoCall.vcf

##vcftools --remove names.txt --vcf FilteredNewNoCall.vcf --out FilteredRM --recode --recode-INFO-all

##vcftools --max-missing 0.5 --vcf FilteredRM.recode.vcf --out FullyFiltered --recode --recode-INFO-all
#vcftools --max-missing 0.5 --vcf FilteredNewNoCall.vcf --out FullyFiltered --recode --recode-INFO-all

#gatk SelectVariants \
 #    -R $reference \
  #   -V FullyFiltered.recode.vcf \
   #  --exclude-filtered -O ExcludeFilters.vcf

#gatk SelectVariants \
 #    -R $reference \
  #   -V ExcludeFilters.vcf \
   #  --exclude-non-variants -O VariantOnly.vcf

##########################################################
echo "VCFtools: Missing INFO"#############################
##########################################################

#vcftools --missing-indv --vcf Genotype.vcf --out missRAW
#vcftools --missing-indv --vcf FilteredNewNoCall.vcf --out missHF
#vcftools --missing-indv --vcf FilteredRM.recode.vcf --out misssampleRem
#vcftools --missing-indv --vcf FullyFiltered.recode.vcf misspossRem
#vcftools --missing-indv --vcf ExcludeFilters.vcf --out missFlagout
#vcftools --missing-indv --vcf VariantOnly.vcf --out missVaronly

