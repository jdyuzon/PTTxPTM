#!/bin/bash
#
#  submit by  sbatch Haplotype_caller.sh
#
#  specify the job name
#SBATCH --job-name=GATK
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=30:00:00
#  maximum requested memory
#SBATCH --mem=15G
#  write std out and std error to these files
#SBATCH --error=gatk.%J.err
#SBATCH --output=gatk.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#  add your code here:

# Haplotype SNP calling

Input_files=/mnt/beegfs/yuzon/aligned/sorted/readgroups/
reference=/mnt/beegfs/yuzon/references/0-1_assembly.v14.fa

cd ${Input_files}

for each in *.read.bam
do

samtools index $each
gatk --java-options "-Xmx4g" HaplotypeCaller \
   -R $reference \
   -I ${each} \
   -ERC BP_RESOLUTION \
   -ploidy 1 \
   -O ${each%_.sorted.read.bam}.vcf.gz

done
