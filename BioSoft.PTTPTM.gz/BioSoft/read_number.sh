#!/bin/bash
#
#  submit by  sbatch read_number.sh
#
#  specify the job name
#SBATCH --job-name=read_number
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=30:00:00
#  maximum requested memory
#SBATCH --mem=10G
#  write std out and std error to these files
#SBATCH --error=read_number.%J.err
#SBATCH --output=read_number.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#  add your code here:

input_dir=/home/yuzon/PTTxPTMtest/raw_reads/
trim_dir=/home/yuzon/PTTxPTMtest/trimmed/
markdup_dir=/home/yuzon/PTTxPTMtest/trimmed/prinseq/

map_dir=/home/yuzon/PTTxPTMtest/aligned/

#cd ${input_dir}

#for each in *1.fq.gz 
#do
#	each2=$(echo ${each%_1.fq.gz}_2.fq.gz)
#	first=$(echo $(zcat $each|wc -l)/4|bc) 
#	second=$(echo $(zcat ${each%_1.fq.gz}_2.fq.gz|wc -l)/4|bc)
#	echo "${each}	${each2}	${first}	${second}" 
#done

####################################
echo "Read Number after Trimming"###
####################################
cd ${trim_dir}

#for each in *_U_1.fastq
#do
#	isolate=${each%_U_1.fastq}
#  	unpaired1=$(echo $(cat $each|wc -l)/4|bc)
#	unpaired2=$(echo $(cat ${each%_1.fastq}_2.fastq|wc -l)/4|bc)
#	pair1=$(echo $(cat ${each%_U_1.fastq}_P_1.fastq|wc -l)/4|bc)
#	pair2=$(echo $(cat ${each%_U_1.fastq}_P_2.fastq|wc -l)/4|bc)
#	total=$(echo = $unpaired1+$unpaired2 + $pair1 + $pair2)
#	echo "$isolate $total"
#done


####################################
echo "Read Number after Markdup"####
####################################
#cd ${markdup_dir}

#for each in *markdup_1.fastq
#do
 # 	isolate=${each%.markdup_1.fastq}
  #      pair1=$(echo $(cat $each|wc -l)/4|bc)
   #     pair2=$(echo $(cat ${isolate}.markdup_2.fastq|wc -l)/4|bc)
#	single=$(echo $(cat ${isolate}.markdup.fastq|wc -l)/4|bc)
 #       total=$(echo $single + $pair1 + $pair2)
  #      echo "$isolate $total"
#done

####################################
echo "Read Number after Markdup"####
####################################
#cd ${qual_dir}

#for each in *_1.qual.fastq
#do
#	isolate=${each%_1.qual.fastq}
 #       pair1=$(echo $(cat $each|wc -l)/4|bc)
  #      pair2=$(echo $(cat ${each%_1.qual.fastq}_2.qual.fastq|wc -l)/4|bc)
   #     single=$(echo $(cat ${each%_1.qual.fastq}.qual.fastq|wc -l)/4|bc)
    #    total=$(echo $single + $pair1 + $pair2)
     #   echo "$isolate $total"
#done


#####################################
echo "Read Number after Mapping"#####
#####################################
cd ${map_dir}

echo "########## Map to PTT ##########"

#for each in *PTT.PE.sam

#do
#	PEreads=$(samtools view -c -F 260 $each)
#	SEreads=$(samtools view -c -F 260 ${each%.PE.sam}.SE.sam)
#	echo "${each}	${PEreads} + ${SEreads}"
#done


echo "########## Map to PTM ##########"

#for each in *PTM.PE.sam
#do
#       PEreads=$(samtools view -c -F 260 $each)
#	SEreads=$(samtools view -c -F 260 ${each%.PE.sam}.SE.sam)
#       echo "${each}   ${PEreads} + ${SEreads}"
#done


#####################################
echo "Read Number after Stampy"#####
#####################################
cd ${map_dir}

echo "########## Map to PTT ##########"

for each in *PTT.PE.stampy.sam

do
  	PEreads=$(samtools view -c -F 260 $each)
        SEreads=$(samtools view -c -F 260 ${each%.PE.stampy.sam}.SE.stampy.sam)
        echo "${each}   ${PEreads} + ${SEreads}"
done


echo "########## Map to PTM ##########"

for each in *PTM.PE.stampy.sam
do
  	PEreads=$(samtools view -c -F 260 $each)
        SEreads=$(samtools view -c -F 260 ${each%.PE.stampy.sam}.SE.stampy.sam)
        echo "${each}   ${PEreads} + ${SEreads}"
done


