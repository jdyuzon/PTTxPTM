#!/bin/bash
#
#  submit by  sbatch missingdata.sh
#
#  specify the job name
#SBATCH --job-name=GATK
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=90:00:00
#  maximum requested memory
#SBATCH --mem=15G
#  write std out and std error to these files
#SBATCH --error=vcf.%J.err
#SBATCH --output=vcf.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#  add your code here:


cd /home/taliadoros/bwa/stampy/sorted/merged/merged/RGed/index/haplotype_caller/

vcftools --missing-indv --vcf Genotype3.7.2.vcf --out missRAW
vcftools --missing-indv --vcf FilteredNewNoCall.vcf --out missHF
vcftools --missing-indv --vcf FilteredRM.recode.vcf --out misssampleRem
vcftools --missing-indv --vcf FullyFiltered.recode.vcf misspossRem
vcftools --missing-indv --vcf ExcludeFilters.vcf --out missFlagout
vcftools --missing-indv --vcf VariantOnly.vcf --out missVaronly
