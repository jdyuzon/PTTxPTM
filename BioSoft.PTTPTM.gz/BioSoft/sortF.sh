#!/bin/bash
#
#  submit by  sbatch depth.sh
#
#  specify the job name
#SBATCH --job-name=samtools
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=20:00:00
#  maximum requested memory
#SBATCH --mem=10G
#  write std out and std error to these files
#SBATCH --error=sam.%J.err
#SBATCH --output=sam.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#  add your code here:

#this script sort reads with respect to their cromosomal position, outputs depth possition, marks PCR artifacts, remove non unic alignments.

aligned_dir=/mnt/beegfs/yuzon/aligned/
Sorted=/mnt/beegfs/yuzon/aligned/sorted/
Depth_dir=/mnt/beegfs/yuzon/aligned/sorted/stats/depth/
dups_dir=/mnt/beegfs/yuzon/aligned/sorted/stats/dups/

cd ${aligned_dir}
for each in *.sam
do
echo ${each}
samtools sort -o ${Sorted}${each%.sam}.sorted.bam -@ 4 ${each}
samtools depth -a ${Sorted}${each%.sam}.sorted.bam > ${Depth_dir}${each}.stats
done

