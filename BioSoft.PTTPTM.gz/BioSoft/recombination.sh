#!/bin/bash
#
#  submit by  sbatch read_number.sh
#
#  specify the job name
#SBATCH --job-name=recombination
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=30:00:00
#  maximum requested memory
#SBATCH --mem=10G
#  write std out and std error to these files
#SBATCH --error=recombination.%J.err
#SBATCH --output=recombination.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

input_dir=/home/yuzon/PTTxPTMtest/SNPcalling/
output_dir=/home/yuzon/PTTxPTMtest/SNPcalling/stats/

mkdir $output_dir

##remove missing data
vcftools --max-missing 0.9 --vcf ${input_dir}VariantOnly.vcf --out ${output_dur}VariantOnly.flt --recode --recode-INFO-all

##interchrom-geno-r2: Outputs a file reporting the r2 statistics for sites on different chromosomes.
vcftools  --vcf  ${output_dur}VariantOnly.flt.recode.vcf --out ${output_dur}VariantOnly_interchrom --interchrom-geno-r2

##geno-r2: Calculates the squared correlation coefficient between genotypes encoded as 0, 1 and 2 to represent the number of non-reference alleles in each individual. This is the same as the LD measure reported by PLINK. 
vcftools  --vcf  ${output_dur}VariantOnly.flt.recode.vcf --out ${output_dur}VariantOnly_genoR2 --geno-r2

