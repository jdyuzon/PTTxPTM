#!/bin/bash
#
#  submit by  sbatch trim.sh
#
#  specify the job name
#SBATCH --job-name=trim
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=10:00:00
#  maximum requested memory
#SBATCH --mem=50G
#  write std out and std error to these files
#SBATCH --error=trim.%J.err
#SBATCH --output=trim.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#  add your code here:

Raw_reads=/mnt/beegfs/yuzon/raw_reads/
trimmo=/data/biosoftware/Trimmomatic/Trimmomatic-0.38/
fastqc=/data/biosoftware/FastQC/FastQC/
out_dir=/mnt/beegfs/yuzon/raw_reads/
fastQCDir=/mnt/beegfs/yuzon/raw_reads/fastQC/

#Trim for adaptors, min qualiti = 28, min leangth = 40

cd ${Raw_reads}
for each in *1.fq.gz
do
echo ${each}
java -jar ${trimmo}trimmomatic-0.38.jar PE -threads 5 \
				$each ${each%1.fq.gz}2.fq.gz \
				${out_dir}${each%1.fq.gz}P_1.fastq ${out_dir}${each%1.fq.gz}U_1.fastq \
				${out_dir}${each%1.fq.gz}P_2.fastq ${out_dir}${each%1.fq.gz}U_2.fastq \
				ILLUMINACLIP:${trimmo}adapters/TruSeq3-PE-2.fa:2:30:10 SLIDINGWINDOW:3:28 MINLEN:99
done

#FastQC

cd ${out_dir}
for each in *fastq
do
${fastqc}fastqc ${each} ${fastQCDir}{each%fastq}fQC
done
