#!/bin/bash

#
#  submit by  sbatch Haplotype_caller.sh
#
#  specify the job name
#SBATCH --job-name=PTTxPTMrecomb
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=90:00:00
#  maximum requested memory
#SBATCH --mem=70G
#  write std out and std error to these files
#SBATCH --error=PTTxPTMrecomb.%J.err
#SBATCH --output=PTTxPTMrecomb.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

##########################################################################################################
################### Get Parental and Hybrid Frequencies ##################################################
##########################################################################################################

file=$1

while read p;
do
  pairs=`echo "$p"| grep -v "SNP"|awk '{print $3 "\t" $6}'`
  /data/biosoftware/plink/v1.07/plink-1.07-x86_64/plink --ld $pairs --file all.recomblocks.ptm.recode --noweb \
  |grep "AA\|TT\|AT\|TA\|A0\|T0\|0A\|0T" |awk '{print $2}' |grep -v "In\|LD\|ld\|info\|phase"| awk 'BEGIN { ORS = " " } { print }'
  echo "$pairs"
done<$file > $file.txt


