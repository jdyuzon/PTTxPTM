#!/bin/bash
#
#  submit by  sbatch bwa.sh
#
#  specify the job name
#SBATCH --job-name=bwa
#  how many cpus are requested
#SBATCH --ntasks=4
#  run on one node, importand if you have more than 1 ntasks
#SBATCH --nodes=1
#  maximum walltime, here 10min
#SBATCH --time=20:00:00
#  maximum requested memory
#SBATCH --mem=10G
#  write std out and std error to these files
#SBATCH --error=bwa.%J.err
#SBATCH --output=bwa.%J.out
#  send a mail for job start, end, fail, etc.
#  which partition?
#  there are global,testing,highmem,standard,fast
#SBATCH --partition=standard

#  add your code here:

trimmed_read_dir=/mnt/beegfs/yuzon/trimmed/prinseq/
bwa_out=/mnt/beegfs/yuzon/aligned/
bwa_soft=/data/biosoftware/bwa/bwa-0.7.15/
ref=/mnt/beegfs/yuzon/references/0-1_assembly.v14.fa
#ref=/mnt/beegfs/yuzon/references/FGOB10Ptm-1_assembly.v7.fasta

cd ${trimmed_read_dir}

${bwa_soft}bwa index ${ref}

for each in *_1.fastqqual.fastq
do
${bwa_soft}bwa mem -M -t 4 ${ref} ${each} ${each%_1.fastqqual.fastq}_2.fastqqual.fastq > ${bwa_out}${each%_1.fastqqual.fastq}.sam
done

